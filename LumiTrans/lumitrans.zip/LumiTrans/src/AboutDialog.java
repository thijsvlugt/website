import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import java.awt.GridLayout;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class AboutDialog extends JDialog
{
  private static final long serialVersionUID = 1L;

  public final int BORDER=7;
	
  public AboutDialog(JFrame frame)
  {
    JPanel panel1 = new JPanel();
    panel1.setAlignmentY(panel1.CENTER_ALIGNMENT);
    panel1.setBorder(BorderFactory.createEmptyBorder(BORDER,BORDER,BORDER,BORDER));
    panel1.setLayout(new GridLayout(12,1,1,5));

    JLabel label1 = new JLabel("LumiTrans - version 0.15 05 May 2011");
    JLabel label2 = new JLabel("A program for fitting luminiscence curves");
    JLabel label3 = new JLabel("Available under the GNU license");
    JLabel label4 = new JLabel("(see LICENSE file)");
    JLabel label5 = new JLabel("");
    JLabel label6 = new JLabel("Authors:");
    JLabel label7 = new JLabel("");
    JLabel label8 = new JLabel("Juan Manuel Castillo S\u00E1nchez");
    JLabel label9 = new JLabel("Thijs J.H. Vlugt");
    JLabel label10 = new JLabel("Delft University of Technology, The Netherlands"); 
    JLabel label11 = new JLabel("Andries Meijerink");
    JLabel label12 = new JLabel("Utrecht University, The Netherlands.");

    label1.setHorizontalAlignment(JLabel.CENTER);
    label2.setHorizontalAlignment(JLabel.CENTER);
    label3.setHorizontalAlignment(JLabel.CENTER);
    label4.setHorizontalAlignment(JLabel.CENTER);
    label5.setHorizontalAlignment(JLabel.CENTER);
    label6.setHorizontalAlignment(JLabel.CENTER);
    label7.setHorizontalAlignment(JLabel.CENTER);
    label8.setHorizontalAlignment(JLabel.CENTER);
    label9.setHorizontalAlignment(JLabel.CENTER);
    label10.setHorizontalAlignment(JLabel.CENTER);
    label11.setHorizontalAlignment(JLabel.CENTER);
    label12.setHorizontalAlignment(JLabel.CENTER);

    panel1.add(label1);
    panel1.add(label2);
    panel1.add(label3);
    panel1.add(label4);
    panel1.add(label5);
    panel1.add(label6);
    panel1.add(label7);
    panel1.add(label8);
    panel1.add(label9);
    panel1.add(label10);
    panel1.add(label11);
    panel1.add(label12);

    JPanel panel2 = new JPanel();
    panel2.setAlignmentY(panel2.CENTER_ALIGNMENT);
    panel2.setBorder(BorderFactory.createEmptyBorder(BORDER,BORDER,BORDER,BORDER));
    panel2.setLayout(new BoxLayout(panel2,BoxLayout.LINE_AXIS));

    JButton button = new JButton("OK");
    button.setMnemonic('O');
    button.addActionListener(new CloseListener());

    panel2.add(button);


    Container thisFrame = getContentPane();
		
    this.setResizable(false);
    this.setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
    this.setLayout(new BoxLayout(thisFrame,BoxLayout.Y_AXIS));

    thisFrame.add(panel1);
    thisFrame.add(panel2);

    this.pack();
    this.setLocationRelativeTo(frame);		
    thisFrame.setVisible(true);
    this.setModalityType(Dialog.ModalityType.TOOLKIT_MODAL);

  }	

//**************************Class methods************************************************
//***************************************************************************************
//***************************************************************************************


//**************************Helper methods***********************************************
//***************************************************************************************
//***************************************************************************************

  private void closeDialog()
  {
    this.dispose(); 
  }


//************************Action listeners***********************************************
//***************************************************************************************
//***************************************************************************************

  private class CloseListener implements ActionListener
  {
    public void actionPerformed(ActionEvent event)
    {			
      closeDialog();
    }
  }
	
}
