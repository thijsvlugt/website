import java.awt.Color;

//This class will only contain the curve parameters, to build a linked list
public class CurveParameters
{
  //Define 9 colors
  final static Color[] colors = {Color.BLACK,Color.RED,Color.BLUE,Color.GREEN,Color.ORANGE,Color.GRAY,Color.MAGENTA,Color.PINK};

  private double x[];
  private double y[];

  private boolean experimental;
  private Color colorID;
  private boolean drawable;

  //Constructor using two vectors of type double
  public CurveParameters(double[] xx, double[] yy)
  {
    x=xx;
    y=yy;
    drawable=true;
  }
  //Constructor using two vectors of doubles and type of curve
  public CurveParameters(double[] xx, double[] yy, boolean type)
  {
    this(xx,yy);
    experimental=type;

    //If the curve is experimental, its color is set to black
    if(experimental) colorID=colors[0];
  }
  //Constructor using two vectors of doubles, type of curve and color
  public CurveParameters(double[] xx, double[] yy, boolean type, Color color)
  {
    this(xx,yy,type);
    colorID=color;
  }


  //Constructor using one matrix of doubles 
  public CurveParameters(double[][] curve)
  {
    x = new double[curve.length];
    y = new double[curve.length];

    for(int i=0;i<curve.length;i++)
    {
      x[i]=curve[i][0];
      y[i]=curve[i][1];
    }
    
    drawable=true;
  }
  //Constructor using one matrix of doubles and type of curve 
  public CurveParameters(double[][] curve, boolean type)
  {
    this(curve);
    experimental=type;
    //If the curve is experimental, its color is set to black
    if(experimental) colorID=colors[0];
  }
  //Constructor using one matrix of doubles, type of curve and color
  public CurveParameters(double[][] curve, boolean type, Color color)
  {
    this(curve,type);
    colorID=color;
  }

  //Constructor that builds one object that does not have to be drawn
  public CurveParameters(boolean toBeDrawn)
  {
    drawable=toBeDrawn;
  }

//**************************Get methods**************************************************
//***************************************************************************************
//***************************************************************************************

  public double getXAtIndex(int i)
  {
    if(!isDrawable()) return 0.0;

    if(i<x.length)
    {
      return x[i];
    }
    else return 0.0;
  }
  public double getYAtIndex(int i)
  {
    if(!isDrawable()) return 0.0;

    if(i<y.length)
    {
      return y[i];
    }
    else return 0.0;
  }
  public boolean isExperimental()
  {
    return experimental;
  }
  public Color getColorID()
  {
    return colorID;
  }
  public boolean isDrawable()
  {
    return drawable;
  }

  public int getLength()
  {
    int index=0;

    if(!isDrawable()) return 0;

    for(int i=0;i<y.length;i++)
    {
      if(y[i]!=0.0) index=i;
    }
    return index;
  }

//**************************Set methods**************************************************
//***************************************************************************************
//***************************************************************************************

  public void setX(double[] xx)
  {
    x=xx;
  }
  public void setY(double[] yy)
  {
    y=yy;
  }
  public void setExperimental(boolean type)
  {
    experimental=type;
  }
  public void setColor(Color c)
  {
    colorID=c;
  }
  public void setDrawable(boolean toBeDrawn)
  {
    drawable=toBeDrawn;
  }

}
