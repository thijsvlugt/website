import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Dialog;
import javax.swing.JProgressBar;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JDialog;
import javax.swing.BorderFactory;

public class ProgressBar extends JDialog
{
  private static final long serialVersionUID = 1L;

  private final int BORDER=7;
  private CalculatorClass calculator;
  double decayCurve[][]; 
  private JLabel titleLabel;
  private JProgressBar progressBar;

  private double curve[][];
  private String neighbours;

  private MainPanel mainPanel;
 
  //Constructor
  public ProgressBar(MainPanel parentFrame,int simulationType)
  {
    mainPanel=parentFrame;

    JPanel progressBarPanel = new JPanel();
    progressBarPanel.setBorder(BorderFactory.createCompoundBorder(
                          BorderFactory.createRaisedBevelBorder(),
                          BorderFactory.createEmptyBorder(BORDER,BORDER,BORDER,BORDER)));
    progressBarPanel.setLayout(new GridLayout(2,1));

    titleLabel = new JLabel("Calculating...");
    progressBarPanel.add(titleLabel);

    progressBar = new JProgressBar(0,100);
    progressBar.setIndeterminate(true);
    progressBar.setStringPainted(true);
    progressBar.setPreferredSize(new Dimension(175,20));
    progressBar.setVisible(true);
    progressBarPanel.add(progressBar);

    Container thisFrame = getContentPane();
    
    thisFrame.add(progressBarPanel);
    this.setUndecorated(true);
    this.pack();
    this.setLocationRelativeTo(parentFrame);
    this.setResizable(false);
    thisFrame.setVisible(true);
    this.setModalityType(Dialog.ModalityType.TOOLKIT_MODAL);

    calculator = new CalculatorClass(parentFrame,parentFrame.getParameters(),simulationType,this);
    calculator.execute();
  }

//**************************Helper methods***********************************************
//***************************************************************************************
//***************************************************************************************

  public void changeMessage(String message)
  {
    titleLabel.setText(message);
  }

  public void setIndeterminateBar(boolean status)
  {
    progressBar.setIndeterminate(status);
  }

  public void setValueBar(int value)
  {
    progressBar.setValue(value);
  }
  
  public void displayCounter(boolean value)
  {
    progressBar.setStringPainted(value);
  }

  public double[][] getCurve()
  {
    return curve;
  }
  //Sets the curve in the main panel
  public void setCurve(double[][] dc)
  {
    mainPanel.setDecayCurve(dc);
  }

  public String getNeighbours()
  {
    return neighbours;
  }
  public void setNeighbours(String n)
  {
    neighbours=n;
  }

  public void closeBar()
  {
    this.dispose();
  }
}

