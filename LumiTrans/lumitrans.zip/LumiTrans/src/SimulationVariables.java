//This class will only contain the cell parameters
public class SimulationVariables extends UnitCellVariables
{
  //model
  private int mechanism;
  private int interaction;
  private int calculation;

  //model parameters
  private double gamma;
  private double c;
  private double origin;
  private String experimentalCurve;

  //simulation parameters
  private int cycles;
  private double step;
  private double sitePercentage;
  private int bins;


  //Empty constructor
  public SimulationVariables()
  {
  }

//**************************Get methods**************************************************
//***************************************************************************************
//***************************************************************************************

  public int getMechanism()
  {
    return mechanism;
  }
  public int getInteraction()
  {
    return interaction;
  }
  public int getCalculation()
  {
    return calculation;
  }
  public double getGamma()
  {
    return gamma;
  }
  public double getC()
  {
    return c;
  }
  public double getOrigin()
  {
    return origin;
  }
  public String getExperimentalCurve()
  {
    return experimentalCurve;
  }
  public int getCycles()
  {
    return cycles;
  }
  public double getStep()
  {
    return step;
  }
  public double getSitesPercentage()
  {
    return sitePercentage;
  }
  public int getBins()
  {
    return bins;
  }

//**************************Set methods**************************************************
//***************************************************************************************
//***************************************************************************************

  public void setMechanism(int m)
  {
    mechanism=m;
  }
  public void setInteraction(int i)
  {
    interaction=i;
  }
  public void setCalculation(int calc)
  {
    calculation=calc;
  }
  public void setGamma(double g)
  {
    gamma=g;
  }
  public void setC(double cc)
  {
    c=cc;
  }
  public void setOrigin(double o)
  {
    origin=o;
  }
  public void setExperimentalCurve(String ec)
  {
    experimentalCurve=ec;
  }
  public void setCycles(int cy)
  {
    cycles=cy;
  }
  public void setStep(double s)
  {
    step=s;
  }
  public void setSitesPercentage(double sp)
  {
    sitePercentage=sp;
  }
  public void setBins(int b)
  {
    bins=b;
  }
}
