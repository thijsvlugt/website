import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.BoxLayout;
import javax.swing.BorderFactory;
import javax.swing.DefaultCellEditor;
import javax.swing.event.DocumentListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.TableModelListener;
import javax.swing.event.TableModelEvent;
import javax.swing.table.TableCellEditor;

public class MainPanel extends JPanel 
{
  private static final long serialVersionUID = 1L;

  final static int BORDER=7; 
  final static int MAX_POINTS=10000; //maximum points in the experimental file

  //Simulation parameters buttons
  private JTextField cyclesField;
  private JTextField timeField;
  private JTextField sitesField;
  private JTextField nBinsField;

  //Unit cell buttons
  private JTextField xField;
  private JTextField yField;
  private JTextField zField;

  private JTextField alphaField;
  private JTextField betaField;
  private JTextField gammaField;

  private JTextField nxField;
  private JTextField nyField;
  private JTextField nzField;

  private JCheckBox periodicBoundariesCheckBox;
  private JCheckBox orthorhombicCheckBox;
  
  private JTextField numberOfAtomsField;

  private ModifiedTableModel positionsModel;
  private String[] columnNames={"atom","x","y","z"};
  private Object[][] data = null;
  private JTable atomPositionTable;
  private boolean positionTableDrawn=false;
  private JScrollPane positionScrollPane;

  //Model buttons
  private JComboBox mechanismComboBox;
  private JComboBox interactionComboBox;
  private JComboBox calculationTypeComboBox;

  //Model parameters buttons
  JTextField gammarField;
  JTextField cField;
  JTextField experimentalCurveField;
  JTextField timeOriginField;

  //To store all the parameters of the simulation
  SimulationVariables parameters;
  //to store the positions of the atoms
  private int atomsInUnitCell=0;
  private int totalNumberOfAtoms;
  private double atomPositions[][];

  //to see if the cell buttons have been changed (for save or not when exit)
  private boolean cellFieldsChanged=false;
  private boolean parameterFieldsChanged=false;
  private boolean experimentalFieldChanged=false;

  //JFrame to comunicate with the parent JFrame
  JFrame parentFrame = new JFrame();

  //Progress bar for the calculations
  ProgressBar progressBar;

  //The dialog for the neighbour list
  NeighboursFrame neighboursWindow;

  //Variable to store the decay curve
  private double decayCurve[][];

  //Frame for plotting the results
  DrawingClass drawingFrame;
  private boolean drawingFrameOpen=false;
  private CurveParameters curveParameters;

  //To check when the calculation was successful
  private boolean isDistanceZero;
  private boolean isConversionZero;
  private boolean isInputTooLarge;
  private boolean isInputFileFound;
  private boolean isWrongInputFormat;
  private boolean enoughMemory;

  //constructor of the class with the parameters that give the size of the panel
  public MainPanel(JFrame mainFrame)
  {

    setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));

    setBorder(BorderFactory.createEmptyBorder(BORDER,BORDER,BORDER,BORDER));

    drawExternalPanel();
    drawMainButtons();

    mainFrame.add(this);

    parentFrame=mainFrame;
  }


  private void drawExternalPanel()
  {
    JPanel outernPanel = new JPanel(); 

    outernPanel.setLayout(new BoxLayout(outernPanel, BoxLayout.PAGE_AXIS));
    outernPanel.setBorder(BorderFactory.createCompoundBorder(
                          BorderFactory.createLineBorder(Color.BLACK,1),
                          BorderFactory.createEmptyBorder(BORDER,BORDER,BORDER,BORDER)));

    drawCellPanel(outernPanel);
    drawModelPanel(outernPanel);
    drawModelParameterslPanel(outernPanel);
    drawSimulationPanel(outernPanel);

    outernPanel.setVisible(true);
    this.add(outernPanel);    
  }


  //Panel that will contain information about the cell
  private void drawCellPanel(JPanel externalPanel)
  {
  
    JPanel cellPanel = new JPanel();
    cellPanel.setBorder(BorderFactory.createTitledBorder("Cell information"));
    cellPanel.setLayout(new BoxLayout(cellPanel, BoxLayout.PAGE_AXIS));

    drawCellInformationPanel(cellPanel);
    drawCheckBoxPanel(cellPanel);
    drawAtomLocationPanel(cellPanel);

    externalPanel.add(cellPanel);
  }

  private void drawCellInformationPanel(JPanel cellExternalPanel)
  {
    JPanel cellInformationPanel = new JPanel();

    cellInformationPanel.setLayout(new GridLayout(1,3,10,5));

    drawCellDimensionsPanel(cellInformationPanel);
    drawCellAnglesPanel(cellInformationPanel);
    drawNumberOfUnitCellsPanel(cellInformationPanel);

    cellExternalPanel.add(cellInformationPanel);
  }


  //Panel that will contain information about the cell dimensions
  private void drawCellDimensionsPanel(JPanel cellInfoPanel)
  {
  
    JPanel cellDimensionsPanel = new JPanel();

    cellDimensionsPanel.setLayout(new GridLayout(3,2,10,5));
    cellDimensionsPanel.setBorder(BorderFactory.createTitledBorder("Size unit cell"));
    cellDimensionsPanel.setToolTipText("Length of the basis vectors spanning the unit cell, in Angstrom");

    //x    
    JLabel xLabel = new JLabel("X");
    xField = new JTextField(1);
    xField.getDocument().addDocumentListener(new GeneralCellFieldListener());

    cellDimensionsPanel.add(xLabel);
    cellDimensionsPanel.add(xField);

    //y    
    JLabel yLabel = new JLabel("Y");
    yField = new JTextField(1);
    yField.getDocument().addDocumentListener(new GeneralCellFieldListener());

    cellDimensionsPanel.add(yLabel);
    cellDimensionsPanel.add(yField);

    //z    
    JLabel zLabel = new JLabel("Z");
    zField = new JTextField(1);
    zField.getDocument().addDocumentListener(new GeneralCellFieldListener());

    cellDimensionsPanel.add(zLabel);
    cellDimensionsPanel.add(zField);


    cellInfoPanel.add(cellDimensionsPanel, BorderLayout.LINE_START);

  }		

  //Panel that will contain information about the cell angles
  private void drawCellAnglesPanel(JPanel cellInfoPanel)
  {

    JPanel cellAnglesPanel = new JPanel();

    cellAnglesPanel.setLayout(new GridLayout(3,2,10,5));
    cellAnglesPanel.setBorder(BorderFactory.createTitledBorder("Cell angles"));
    cellAnglesPanel.setToolTipText("Angles between the basis vectors spanning the unit cell, in degrees");

    //alpha    
    JLabel alphaLabel = new JLabel("alpha");
    alphaField = new JTextField("90.0",1);
    alphaField.setEditable(false);
    alphaField.getDocument().addDocumentListener(new GeneralCellFieldListener());

    cellAnglesPanel.add(alphaLabel);
    cellAnglesPanel.add(alphaField);

    //beta    
    JLabel betaLabel = new JLabel("beta");
    betaField = new JTextField("90.0",1);
    betaField.setEditable(false);
    betaField.getDocument().addDocumentListener(new GeneralCellFieldListener());

    cellAnglesPanel.add(betaLabel);
    cellAnglesPanel.add(betaField);

    //gamma    
    JLabel gammaLabel = new JLabel("gamma");
    gammaField = new JTextField("90.0",1);
    gammaField.setEditable(false);
    gammaField.getDocument().addDocumentListener(new GeneralCellFieldListener());

    cellAnglesPanel.add(gammaLabel);
    cellAnglesPanel.add(gammaField);


    cellInfoPanel.add(cellAnglesPanel, BorderLayout.LINE_START);

  }

  //Panel that will contain information about the number of unit cells
  private void drawNumberOfUnitCellsPanel(JPanel cellInfoPanel)
  {
  
    JPanel numberOfUnitCellsPanel = new JPanel();

    numberOfUnitCellsPanel.setLayout(new GridLayout(3,2,10,5));
    numberOfUnitCellsPanel.setBorder(BorderFactory.createTitledBorder("# of unit cells"));
    numberOfUnitCellsPanel.setToolTipText("Number of unit cells in the x,y,z directions");

    //nx    
    JLabel nxLabel = new JLabel("NX");
    nxField = new JTextField(1);
    nxField.getDocument().addDocumentListener(new GeneralCellFieldListener());

    numberOfUnitCellsPanel.add(nxLabel);
    numberOfUnitCellsPanel.add(nxField);

    //ny    
    JLabel nyLabel = new JLabel("NY");
    nyField = new JTextField(1);
    nyField.getDocument().addDocumentListener(new GeneralCellFieldListener());

    numberOfUnitCellsPanel.add(nyLabel);
    numberOfUnitCellsPanel.add(nyField);

    //nz    
    JLabel nzLabel = new JLabel("NZ");
    nzField = new JTextField(1);
    nzField.getDocument().addDocumentListener(new GeneralCellFieldListener());

    numberOfUnitCellsPanel.add(nzLabel);
    numberOfUnitCellsPanel.add(nzField);


    cellInfoPanel.add(numberOfUnitCellsPanel, BorderLayout.LINE_END);

  }

  private void drawCheckBoxPanel(JPanel cellExternalPanel)
  {

    JPanel checkBoxPanel = new JPanel();
    checkBoxPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

    periodicBoundariesCheckBox = new JCheckBox("Periodic boundaries",true);
    orthorhombicCheckBox = new JCheckBox("Orthorhombic-tetragonal-cubic",true);

    periodicBoundariesCheckBox.setToolTipText("Check this box for using periodic boundary conditions");
    orthorhombicCheckBox.setToolTipText("Check this box when all unit cell angles are 90 degrees");

    periodicBoundariesCheckBox.addItemListener(new PeriodicBoundariesListener());
    orthorhombicCheckBox.addItemListener(new OrthorhombicListener());

    checkBoxPanel.add(periodicBoundariesCheckBox);
    checkBoxPanel.add(orthorhombicCheckBox);
    checkBoxPanel.add(new JPanel());

    cellExternalPanel.add(checkBoxPanel);
  }


  //Panel that will contain the atom location buttons
  private void drawAtomLocationPanel(JPanel cellInfoPanel)
  {
  
    JPanel atomLocationPanel = new JPanel();

    atomLocationPanel.setBorder(BorderFactory.createTitledBorder("Relative atom positions"));
    atomLocationPanel.setLayout(new BoxLayout(atomLocationPanel, BoxLayout.PAGE_AXIS));

    drawNumberOfAtomsPanel(atomLocationPanel);
    drawPositionTable(atomLocationPanel);
    drawPositionButtonsPanel(atomLocationPanel);

    cellInfoPanel.add(atomLocationPanel);
  }

  private void drawNumberOfAtomsPanel(JPanel atomPositionPanel)
  {
    JPanel numberOfAtomsPanel = new JPanel();
    numberOfAtomsPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

    JLabel numberOfAtomsLabel = new JLabel("Number of atoms         ");
    numberOfAtomsLabel.setToolTipText("Number of atoms per unit cell");
    numberOfAtomsField = new JTextField(3);
    numberOfAtomsField.setText("");
    numberOfAtomsField.getDocument().addDocumentListener(new NumberOfAtomsListener());
 
    numberOfAtomsPanel.add(numberOfAtomsLabel);
    numberOfAtomsPanel.add(numberOfAtomsField);

    atomPositionPanel.add(numberOfAtomsPanel);
  }

  private void drawPositionTable(JPanel atomPositionPanel)
  {
    positionsModel = new ModifiedTableModel(data,columnNames);
    positionsModel.addTableModelListener(new PositionsModelListener());
    atomPositionTable = new JTable(positionsModel);
    atomPositionTable.getTableHeader().setReorderingAllowed(false);
    atomPositionTable.setPreferredScrollableViewportSize(new Dimension(100,50));

    positionScrollPane = new JScrollPane(atomPositionTable);
    positionScrollPane.createVerticalScrollBar();
    positionScrollPane.setBorder(BorderFactory.createEmptyBorder(BORDER,0,BORDER,0));
    positionScrollPane.setMaximumSize(new Dimension(800,50));

    atomPositionPanel.add(positionScrollPane);
  }

  private void drawPositionButtonsPanel(JPanel atomPositionPanel)
  {
    JPanel positionButtonsPanel = new JPanel();
    positionButtonsPanel.setLayout(new GridLayout(1,4,10,5));

    JButton loadButton = new JButton("Load");
    JButton saveButton = new JButton("Save");
    JButton neighboursButton = new JButton("Neighbours");

    loadButton.setMnemonic('l');
    saveButton.setMnemonic('s');
    neighboursButton.setMnemonic('n');

    loadButton.addActionListener(new LoadListener());
    saveButton.addActionListener(new SaveListener());
    neighboursButton.addActionListener(new NeighboursListener());

    positionButtonsPanel.add(new JLabel());
    positionButtonsPanel.add(loadButton);
    positionButtonsPanel.add(saveButton);
    positionButtonsPanel.add(neighboursButton);

    atomPositionPanel.add(positionButtonsPanel);
  }


  //Panel that contains model and type of calculation
  private void drawModelPanel(JPanel externalPanel)
  {
    JPanel modelPanel = new JPanel();

    modelPanel.setBorder(BorderFactory.createTitledBorder("Model"));
    modelPanel.setLayout(new GridLayout(2,4,10,5));

    drawModelChoicePanel(modelPanel);

    externalPanel.add(modelPanel);
 
  }

  private void drawModelChoicePanel(JPanel modelPanel)
  {

    JLabel mechanismComboLabel = new JLabel("Mechanism");
    JLabel interactionComboLabel = new JLabel("Interaction model");

    mechanismComboLabel.setToolTipText("Choose the mechanism: single transfer, cooperative, accretive");
    interactionComboLabel.setToolTipText("Choose the interaction model: dipole-dipole, dipole-quadrupole, quadrupole-quadrupole");

    String [] mechanismOptions   =  {"","single transfer","cooperative","acretive"};
    String [] interactionOptions =  {"","dp-dp","dp-qdp","qdp-qdp"};

    mechanismComboBox   = new JComboBox(mechanismOptions);
    interactionComboBox = new JComboBox(interactionOptions);

    mechanismComboBox.addItemListener(new GeneralParameterItemListener());
    modelPanel.add(mechanismComboLabel);
    modelPanel.add(mechanismComboBox);

    JLabel calculationTypeComboLabel = new JLabel("User input");
    calculationTypeComboLabel.setToolTipText("<HTML>Choose the type of calculation:<BR> 1. User provides values for Grad and C<BR>" +
                                             " 2. User provides value for Grad, as well as an experimental decay curve. Program will fit the value of C<BR>" +
                                             " 3. User provides value for C, as well as an experimental decay curve. Program will fit the value of Grad<BR>" +
                                             " 4. User provides an experimental decay curve. Program will fit values for C and Grad</HTML>");

    String [] calculationTypeOptions   =  {"","Grad + c","Grad + exp.","c + exp.","exp."};

    calculationTypeComboBox = new JComboBox(calculationTypeOptions);

    calculationTypeComboBox.addItemListener(new GeneralParameterItemListener());
    modelPanel.add(calculationTypeComboLabel);
    modelPanel.add(calculationTypeComboBox);

    interactionComboBox.addItemListener(new GeneralParameterItemListener());
    modelPanel.add(interactionComboLabel);
    modelPanel.add(interactionComboBox);

    modelPanel.add(new JLabel(""));
  }

  private void  drawModelParameterslPanel(JPanel externalPanel)
  {
    JPanel modelParametersPanel = new JPanel();

    modelParametersPanel.setBorder(BorderFactory.createTitledBorder("Model parameters"));
    modelParametersPanel.setLayout(new GridLayout(2,1,10,5));

    drawModelParametersFirstPanel(modelParametersPanel);
    drawModelParametersSecondPanel(modelParametersPanel);

    externalPanel.add(modelParametersPanel);
  }

  private void drawModelParametersFirstPanel(JPanel modelPanel)
  {
    JPanel modelParametersFirstPanel = new JPanel();
    modelParametersFirstPanel.setBorder(BorderFactory.createEmptyBorder(BORDER,BORDER,0,BORDER));
    modelParametersFirstPanel.setLayout(new GridLayout(1,6,10,5));
 
    JLabel gammarLabel = new JLabel("Grad");
    gammarLabel.setToolTipText("Rate constant for radiative decay");
    gammarField = new JTextField(3);
    JLabel cLabel = new JLabel("      C");
    cLabel.setToolTipText("Parameter in non-radiative decay model");
    cField = new JTextField(3);
    JLabel timeOriginLabel = new JLabel("Time origin");
    timeOriginLabel.setToolTipText("Set the time origin for the experimental decay curve");
    timeOriginField = new JTextField(3);

    gammarField.getDocument().addDocumentListener(new GeneralParameterFieldListener());
    cField.getDocument().addDocumentListener(new GeneralParameterFieldListener());
    timeOriginField.getDocument().addDocumentListener(new GeneralParameterFieldListener());
   
    modelParametersFirstPanel.add(gammarLabel); 
    modelParametersFirstPanel.add(gammarField); 
    modelParametersFirstPanel.add(cLabel); 
    modelParametersFirstPanel.add(cField);
    modelParametersFirstPanel.add(timeOriginLabel); 
    modelParametersFirstPanel.add(timeOriginField);

    modelPanel.add(modelParametersFirstPanel); 

  }

  private void drawModelParametersSecondPanel(JPanel modelPanel)
  {
    JPanel modelParametersSecondPanel = new JPanel();
    modelParametersSecondPanel.setBorder(BorderFactory.createEmptyBorder(BORDER,BORDER,0,BORDER));
    modelParametersSecondPanel.setLayout(new GridLayout(1,3,10,5));

    JLabel experimentalCurveLabel = new JLabel("Experimental curve");
    experimentalCurveLabel.setToolTipText("Filename for the experimental decay curve");
    experimentalCurveField = new JTextField(3);
    JButton experimentalCurveBrowseButton = new JButton("Browse");

    experimentalCurveField.getDocument().addDocumentListener(new ExperimentalFieldListener());

    experimentalCurveBrowseButton.setMnemonic('B');
    experimentalCurveBrowseButton.addActionListener(new BrowseButtonListener());

    modelParametersSecondPanel.add(experimentalCurveLabel);
    modelParametersSecondPanel.add(experimentalCurveField);
    modelParametersSecondPanel.add(experimentalCurveBrowseButton);

    modelPanel.add(modelParametersSecondPanel);

  }


  //Panel for simulation parameters
  private void drawSimulationPanel(JPanel externalPanel)
  {
    //Build one panel for adding the simulation parameters with default flow layout
    JPanel simulationPanel = new JPanel();
    simulationPanel.setLayout(new GridLayout(2,4,10,5));
    setBorder(BorderFactory.createEmptyBorder(BORDER,BORDER,BORDER,BORDER));

    //Cycles    
    JLabel cyclesLabel = new JLabel("# of configurations");
    cyclesLabel.setToolTipText("Number of random realizations of the acceptor ions");
    cyclesField = new JTextField(3);

    cyclesField.getDocument().addDocumentListener(new GeneralParameterFieldListener());
    simulationPanel.add(cyclesLabel);
    simulationPanel.add(cyclesField);

    //Time step
    JLabel timeLabel = new JLabel("Time step");
    timeLabel.setToolTipText("Time step for calculating the decay curve");
    timeField = new JTextField(3);

    timeField.getDocument().addDocumentListener(new GeneralParameterFieldListener());
    simulationPanel.add(timeLabel);
    simulationPanel.add(timeField);
    
    //% acceptor sites
    JLabel sitesLabel = new JLabel("% acceptor sites");
    sitesLabel.setToolTipText("Percentage of acceptor sites");
    sitesField = new JTextField(3);

    sitesField.getDocument().addDocumentListener(new GeneralParameterFieldListener());
    simulationPanel.add(sitesLabel);
    simulationPanel.add(sitesField);

    //Print every
    JLabel nBinsLabel = new JLabel("Number of bins");
    nBinsLabel.setToolTipText("Number of timesteps for computing the decay curve");
    nBinsField = new JTextField(3);

    nBinsField.getDocument().addDocumentListener(new GeneralParameterFieldListener());
    simulationPanel.add(nBinsLabel);
    simulationPanel.add(nBinsField);

    simulationPanel.setBorder(BorderFactory.createTitledBorder("Simulation parameters"));
    externalPanel.add(simulationPanel);
  }
  
  
  private void drawMainButtons()
  {
    JPanel mainButtonsPanel = new JPanel();

    mainButtonsPanel.setLayout(new GridLayout(1,4,10,5));
    mainButtonsPanel.setBorder(BorderFactory.createEmptyBorder(BORDER,BORDER,0,BORDER));

    JButton runButton = new JButton("Run");
    JButton resetButton = new JButton("Reset");
    JButton exitButton = new JButton("Exit");

    runButton.setMnemonic('R');
    resetButton.setMnemonic('E');
    exitButton.setMnemonic('X');

    runButton.addActionListener(new RunListener());
    resetButton.addActionListener(new ResetListener());
    exitButton.addActionListener(new ExitListener());

    mainButtonsPanel.add(new JPanel());
    mainButtonsPanel.add(runButton);
    mainButtonsPanel.add(resetButton);
    mainButtonsPanel.add(exitButton);

    this.add(mainButtonsPanel);
  }

//*********************Other classes (no events)*****************************************
//***************************************************************************************
//***************************************************************************************

  private class ModifiedTableModel extends DefaultTableModel
  {
    private static final long serialVersionUID = 1L;

    //calls the constructor we need of the parent class
    public ModifiedTableModel(Object[][] data,Object[] columnNames)
    {
      super(data,columnNames);
    }

    //overwrites the method of the parent class to make the first column no editable
    public boolean isCellEditable(int row, int column)
    {
      if(column==0)
      {
        return false;
      }
      return true;
    } 
  }

//**************************Set methods**************************************************
//***************************************************************************************
//***************************************************************************************

  public void setDecayCurve(double[][] curve)
  {
    decayCurve=curve;
  }

  public void setDrawingFrameOpen(boolean open)
  {
    drawingFrameOpen=open;
  }

  public void setExperimentalFieldChanged(boolean changed)
  {
    experimentalFieldChanged=changed;
  }

  public void setProgressBarVisible()
  {
    if(progressBar!=null)
    {
      progressBar.setVisible(true);
    }
  }

  public void setDistanceZero(boolean value)
  {
    isDistanceZero=value;
  }

  public void setConversionZero(boolean value)
  {
    isConversionZero=value;
  }

  public void setInputTooLarge(boolean value)
  {
    isInputTooLarge=value;
  }

  public void setInputFileFound(boolean value)
  {
    isInputFileFound=value;
  }

  public void setWrongInputFormat(boolean value)
  {
    isWrongInputFormat=value;
  }

  public void setEnoughMemory(boolean value)
  {
    enoughMemory=value;
  }

  public void closeProgressBar()
  {
    if(progressBar!=null)
    {
      progressBar.closeBar();
    }
  }

//**************************Get methods**************************************************
//***************************************************************************************
//***************************************************************************************

  public double[][] getDecayCurve()
  {
    return decayCurve;
  }

  public SimulationVariables getParameters()
  {
    return parameters; 
  }

  public boolean isDrawingFrameOpen()
  {
    return drawingFrameOpen;
  }

  public boolean isEnoughMemory()
  {
    return enoughMemory;
  }

//**************************Helper methods***********************************************
//***************************************************************************************
//***************************************************************************************

    
  //loads a cell information file, check if it is valid, and fills the information in the GUI
  private void readCellInfoFile()
  {
    int openFileResult;
    String line="";
    String parameters[] = new String[3]; 
    File cellInfoFile=null;
    JFileChooser myFileChooser = new JFileChooser("./CellDescription");
    int atom,numberOfAtoms;
    int linesInTable;

    //Open a file chooser for files only, and store the action of the user
    myFileChooser.setFileSelectionMode(myFileChooser.FILES_ONLY);
    openFileResult=myFileChooser.showOpenDialog(this);

    //We exit this method if the user press cancel
    if(openFileResult==JFileChooser.CANCEL_OPTION)
    {
      return;
    }

    //store the file chosen by the user
    cellInfoFile=myFileChooser.getSelectedFile();

    //Check that the file name is valid
    if ((cellInfoFile==null)||(cellInfoFile.getName().equals("")))
    {
      JOptionPane.showMessageDialog(this,"File name not valid",
                                      "File not valid", JOptionPane.ERROR_MESSAGE);
    }
    else
    {
      //Create a read buffer for the input file
      try
      {
        FileReader cellInfoReader = new FileReader (cellInfoFile);
        BufferedReader cellInfoBuffer = new BufferedReader(cellInfoReader);

        //read the information in the file and change the GUI accordingly
        //read the information about the unit cell
        line=cellInfoBuffer.readLine();
        parameters=line.split("\t");

        xField.setText(parameters[0]);
        yField.setText(parameters[1]);
        zField.setText(parameters[2]);

        xField.setCaretPosition(0);
        yField.setCaretPosition(0);
        zField.setCaretPosition(0);
    
        //read the information about the angles
        line=cellInfoBuffer.readLine();
        parameters=line.split("\t");

        alphaField.setEditable(true);
        betaField.setEditable(true);
        gammaField.setEditable(true);

        orthorhombicCheckBox.setSelected(false);

        alphaField.setText(parameters[0]);
        betaField.setText(parameters[1]);
        gammaField.setText(parameters[2]);

        if((Double.parseDouble(parameters[0])-90.0)<1e-5&&
           (Double.parseDouble(parameters[1])-90.0)<1e-5&&
           (Double.parseDouble(parameters[2])-90.0)<1e-5)
        {
          alphaField.setEditable(false);
          betaField.setEditable(false);
          gammaField.setEditable(false);    
           
          orthorhombicCheckBox.setSelected(true);
        }

        //read the information about the number of unit cells
        line=cellInfoBuffer.readLine();
        parameters=line.split("\t");

        nxField.setText(parameters[0]);
        nyField.setText(parameters[1]);
        nzField.setText(parameters[2]);

        //read the information about the periodic boundary conditions
        line=cellInfoBuffer.readLine();
        if(Integer.parseInt(line)==0)
        {
          periodicBoundariesCheckBox.setSelected(false);
        }
        else
        {
          periodicBoundariesCheckBox.setSelected(true);
        }

        //read the number of atoms in the unit cell
        line=cellInfoBuffer.readLine();
        numberOfAtomsField.setText(line);
        atomsInUnitCell=Integer.parseInt(line);

        //Check the number of atoms before writing the atoms in the table
        if(atomsInUnitCell<=0)
        {
          throw new IOException();
        }

        //add or delete lines in the table to store atom positions
        linesInTable=atomPositionTable.getRowCount();
        if(linesInTable<atomsInUnitCell)
        {
          for(int i=0;i<atomsInUnitCell-linesInTable;i++)
          {
            positionsModel.addRow(new Object[] {" "," "," "," "});
          }
        }
        else if(linesInTable>atomsInUnitCell)
        {
          for(int i=0;i<(linesInTable-atomsInUnitCell);i++)
          {
            positionsModel.removeRow(atomPositionTable.getRowCount());
          }
        }

        //read the atomic positions and display them in the table
        for(atom=0;atom<atomsInUnitCell;atom++)
        {
          line=cellInfoBuffer.readLine();
          parameters=line.split("\t");
 
          atomPositionTable.setValueAt(String.valueOf(atom+1),atom,0);  
          atomPositionTable.setValueAt(parameters[0],atom,1);  
          atomPositionTable.setValueAt(parameters[1],atom,2);  
          atomPositionTable.setValueAt(parameters[2],atom,3);  
        }

        //Finally, check that the parameters read are right
        if(!cellParametersOK(false))
        {
          JOptionPane.showMessageDialog(this,"There was an error reading the file\n" + "The atomic positions must be given in unitary units",
                                     "Read file error", JOptionPane.ERROR_MESSAGE);
          resetCellFields();
          return;
        }

        //Close the file and the buffers
        cellInfoBuffer.close();
        cellInfoReader.close();
        cellInfoFile=null;

        cellFieldsChanged=false;
      }
      catch (IOException exception)
      {
        JOptionPane.showMessageDialog(this,"The selected file could not be read",
                                     "Read file error", JOptionPane.ERROR_MESSAGE);
        resetCellFields();
        return;
      }
      catch (ArrayIndexOutOfBoundsException exception)
      {
        JOptionPane.showMessageDialog(this, "The format of the input file is not valid",
                               "Wrong input format",JOptionPane.ERROR_MESSAGE);
        resetCellFields();
        return;
      }

    }

  }

  //we make this function public because it will be used by the main program that calls this class when exiting
  //returns true if we can simply exit the program, and 1 otherwise
  public boolean writeCellInfoFile(boolean displayInfo)
  {
    int saveFileResult;
    File cellInfoFile=null;

    //First check if it is necessary to save
    if(!cellFieldsChanged)
    {
      if(displayInfo)
      {
        JOptionPane.showMessageDialog(this,"The cell information has not changed",
                                          "Save", JOptionPane.INFORMATION_MESSAGE);
      }
      return true;
    }
    //Check that the information about the cell is right
    if(!cellParametersOK(false))
    {
      if(displayInfo)
      {
        JOptionPane.showMessageDialog(this,"Please fill all the cell information fields with valid parameters",
                                          "Save", JOptionPane.WARNING_MESSAGE);
      }
      return true;
    }

    //For save when exit, show a message asking if the user want to save when the cell information has changed and it is valid
    if(!displayInfo)
    {
      String options[] = {"Yes","No","Cancel"};

      int option = JOptionPane.showOptionDialog(this,"The cell information has changed.\nDo you want to save the changes?", "Exit",
                                   JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE,null,options,options[0]);
      if(option==JOptionPane.NO_OPTION)
      {
        return true;
      }
      if(option==JOptionPane.CANCEL_OPTION)
      {
        return false;
      }
      if(option==JOptionPane.YES_OPTION)
      {
        displayInfo=true;
      }
    }

   
    if(displayInfo)
    { 
      //Write in the output the cell information
      //Open a file chooser for files only, and store the action of the user
      JFileChooser myFileChooser = new JFileChooser("./CellDescription");
      myFileChooser.setFileSelectionMode(myFileChooser.FILES_ONLY);

      saveFileResult=myFileChooser.showSaveDialog(this);

      //We exit this method if the user press cancel
      if (saveFileResult==JFileChooser.CANCEL_OPTION)
      {
        return false;
      }
  
      //store the file chosen by the user
      cellInfoFile=myFileChooser.getSelectedFile();

      //Check that the file name is valid
      if ((cellInfoFile==null)||(cellInfoFile.getName().equals("")))
      {
        JOptionPane.showMessageDialog(this,"File name not valid",
                                        "File not valid", JOptionPane.ERROR_MESSAGE);
      }
      else
      {
        try
        {
          //Create an output buffer for the file
          FileOutputStream cellInfoStream = new FileOutputStream(cellInfoFile);
          PrintWriter cellInfoWriter = new PrintWriter(cellInfoStream);

          //We write in the output the information in the right format
          cellInfoWriter.println(xField.getText() + "\t" + yField.getText() + "\t" + zField.getText());
          cellInfoWriter.println(alphaField.getText() + "\t" + betaField.getText() + "\t" + gammaField.getText());
          cellInfoWriter.println(nxField.getText() + "\t" + nyField.getText() + "\t" + nzField.getText());
          if(periodicBoundariesCheckBox.isSelected())
          {
            cellInfoWriter.println("1");
          }
          else
          {
            cellInfoWriter.println("0");
          }
          cellInfoWriter.println(numberOfAtomsField.getText());

          for(int i=0;i<Integer.parseInt(numberOfAtomsField.getText());i++)
          {
            cellInfoWriter.println(atomPositionTable.getValueAt(i,1) + "\t" + atomPositionTable.getValueAt(i,2) + "\t" + atomPositionTable.getValueAt(i,3));
          }
        
          cellInfoWriter.close();
          cellInfoStream.close();
          cellInfoFile=null;
        }
        catch (IOException excepcion)
        {
          JOptionPane.showMessageDialog(this,"The selected file could not be saved",
                                       "Save file error", JOptionPane.ERROR_MESSAGE);
          return false;
        }

      }
    }
    //As the file has been saved, change the changed status of the cell fields
    cellFieldsChanged=false;
    return true;
  }

  //adds or delete cells in the positions table depending on the number of atoms
  private void refreshPositionTable(String atoms)
  {
    int linesInTable;
    int numberOfAtoms;

    try
    {
      numberOfAtoms=Integer.parseInt(atoms);

      if(numberOfAtoms<=0)
      {
        JOptionPane.showMessageDialog(this,"The number of atoms must be a positive number",
                                 "Error in 'Number of atoms'", JOptionPane.ERROR_MESSAGE);
        return;
      }
      else if(numberOfAtoms>1000)
      {
        JOptionPane.showMessageDialog(this,"The maximum number of atoms is 1000 per unit cell",
                                 "Error in 'Number of atoms'", JOptionPane.ERROR_MESSAGE);
        return;
      }
    }
    catch(NumberFormatException exception)
    {
      if(!atoms.equalsIgnoreCase(""))
      {
        JOptionPane.showMessageDialog(this,"The number of atoms must be a positive integer",
                                          "Error in 'Number of atoms'", JOptionPane.ERROR_MESSAGE);
      }
      return;
    }

    //add or delete the necessary number of rows in the table
    linesInTable=atomPositionTable.getRowCount();
    if(linesInTable<numberOfAtoms)
    {
      for(int i=0;i<numberOfAtoms-linesInTable;i++)
      {
        positionsModel.addRow(new Object[] {" "," "," "," "});
        atomPositionTable.setValueAt(String.valueOf(atomPositionTable.getRowCount()),atomPositionTable.getRowCount()-1,0);  
      }
    }
    else if(linesInTable>numberOfAtoms)
    {
      for(int i=0;i<(linesInTable-numberOfAtoms);i++)
      {
        positionsModel.removeRow(atomPositionTable.getRowCount()-1);
      }
    }
  }

  private void fillExperimentalFileName()
  {
    int browseFileResult;
    File experimentalFile;
 
    JFileChooser myFileChooser = new JFileChooser("./ExperimentalDecayCurves");      
    myFileChooser.setFileSelectionMode(myFileChooser.FILES_ONLY);
    browseFileResult=myFileChooser.showOpenDialog(this);

    //We exit this method if the user press cancel
    if(browseFileResult==JFileChooser.CANCEL_OPTION)
    {
      return;
    }

    //store the file chosen by the user
    experimentalFile=myFileChooser.getSelectedFile();

    //Check that the file name is valid
    if ((experimentalFile==null)||(experimentalFile.getName().equals("")))
    {
      JOptionPane.showMessageDialog(this,"File name not valid",
                                      "File not valid", JOptionPane.ERROR_MESSAGE);

      return;
    }

    experimentalCurveField.setText(experimentalFile.getPath());
    parameterFieldsChanged=true;
    experimentalFieldChanged=true;

    experimentalFile=null;
  }

  private void displayNeighbours()
  {
    double atomicPositions[][];
    int atoms;

    //Stop editing cells
    stopCellEditingCells();

    //This variable in fact will only be used for its UnitCellVariables parameters and functions
    parameters = new SimulationVariables();

    //Check first that the cell info is right (including the number of atoms, needed to reserve memory
    if(!cellParametersOK(true))
    {
      return;
    }

    atoms=Integer.parseInt(numberOfAtomsField.getText());
    atomicPositions = new double [atoms][3];
    
    if(fillCellInfo(parameters))
    {
      neighboursWindow = new NeighboursFrame(this,parameters);
      neighboursWindow.setVisible(true);
    }

    if(!enoughMemory)
    {
      JOptionPane.showMessageDialog(this,"There is not enough memory to perform this calculation\n" +
                                         "Please reduce the number of unit cells",
                                      "Not enough memory", JOptionPane.ERROR_MESSAGE);
    }
    neighboursWindow.dispose();
  }
  
  //Converts strings to proper numbers and store the information in one UnitCellVariables object
  //If returns false if any atomic position is repeated
  private boolean fillCellInfo(SimulationVariables cell)
  {
    double dummy[] = new double[3];
    double atom[][] = new double[Integer.parseInt(numberOfAtomsField.getText())][3];
    int dummyInt[] = new int[3];
    double dx,dy,dz,d;
    
    dummy[0]=Double.parseDouble(xField.getText()); 
    dummy[1]=Double.parseDouble(yField.getText()); 
    dummy[2]=Double.parseDouble(zField.getText()); 

    cell.setCellParameters(dummy);

    dummy[0]=Double.parseDouble(alphaField.getText()); 
    dummy[1]=Double.parseDouble(betaField.getText()); 
    dummy[2]=Double.parseDouble(gammaField.getText()); 

    cell.setAngleParameters(dummy);

    dummyInt[0]=Integer.parseInt(nxField.getText()); 
    dummyInt[1]=Integer.parseInt(nyField.getText()); 
    dummyInt[2]=Integer.parseInt(nzField.getText()); 

    cell.setNParameters(dummyInt);

    if(periodicBoundariesCheckBox.isSelected())
    {
      cell.setPeriodic(true);
    }
    else
    {
      cell.setPeriodic(false);
    }

    cell.setAtoms(Integer.parseInt(numberOfAtomsField.getText()));

    for(int i=0;i<Integer.parseInt(numberOfAtomsField.getText());i++)
    {
      atom[i][0]=Double.parseDouble(String.valueOf(atomPositionTable.getValueAt(i,1)));
      atom[i][1]=Double.parseDouble(String.valueOf(atomPositionTable.getValueAt(i,2)));
      atom[i][2]=Double.parseDouble(String.valueOf(atomPositionTable.getValueAt(i,3)));

      //Check that the positions are not repeated
      for(int j=0;j<i;j++)
      {
        //Calculate distance between couples of atoms
        dx=atom[i][0]-atom[j][0];
        dy=atom[i][1]-atom[j][1];
        dz=atom[i][2]-atom[j][2];

        //apply boundary conditions
        if(dx>0.5) dx=1-dx;
        if(dx<-0.5) dx=1+dx;
        if(dy>0.5) dy=1-dy;
        if(dy<-0.5) dy=1+dy;
        if(dz>0.5) dz=1-dz;
        if(dz<-0.5) dz=1+dz;

        //Calculate distances between atoms
        d=Math.sqrt(dx*dx+dy*dy+dz*dz);

        if(d<1e-3)
        {
          JOptionPane.showMessageDialog(this,"Some atomic positions are repeated",
                                      "Repeated positions", JOptionPane.WARNING_MESSAGE);
          return false;
        }
      }
    }
   
    cell.setPositions(atom);

    return true;
  }

  //Converts strings to proper numbers and store the information in one SimulationVariables object
  //Returns false if the atomic positions are repeated
  private boolean fillSimulationVariables(SimulationVariables variables)
  {
    if(!fillCellInfo(variables))
    {
      return false;
    }

    variables.setMechanism(mechanismComboBox.getSelectedIndex());
    variables.setInteraction(interactionComboBox.getSelectedIndex());
    variables.setCalculation(calculationTypeComboBox.getSelectedIndex());

    //Fill only relevant variables depending on the calculation type
    //If no required parameters are filled, use them as an starting guess for the calculation, if not set them to zero
    switch(variables.getCalculation())
    {
      case 1:  //gamma + c
        variables.setGamma(Double.parseDouble(gammarField.getText()));
        variables.setC(Double.parseDouble(cField.getText()));  
        break;
      case 2:  //gamma + experiment
        variables.setGamma(Double.parseDouble(gammarField.getText()));
        try
        {
          variables.setC(Double.parseDouble(cField.getText()));  
        }
        catch(NumberFormatException exception)
        {
          variables.setC(0.0);
        }
        break;
      case 3:  //c + experiment
        variables.setC(Double.parseDouble(cField.getText()));  
        try
        {
          variables.setGamma(Double.parseDouble(gammarField.getText()));  
        }
        catch(NumberFormatException exception)
        {
          variables.setGamma(0.0);
        }
        break;
      case 4:  //experiment
        try
        {
          variables.setGamma(Double.parseDouble(gammarField.getText()));  
        }
        catch(NumberFormatException exception)
        {
          variables.setGamma(0.0);
        }
        try
        {
          variables.setC(Double.parseDouble(cField.getText()));  
        }
        catch(NumberFormatException exception)
        {
          variables.setC(0.0);
        }
        break;
    }
    //The experimental curve is always read as it will be plotted if it is present
    variables.setExperimentalCurve(experimentalCurveField.getText());
    if(!variables.getExperimentalCurve().equalsIgnoreCase(""))
    {
      variables.setOrigin(Double.parseDouble(timeOriginField.getText()));
    }

    variables.setCycles(Integer.parseInt(cyclesField.getText()));
    variables.setStep(Double.parseDouble(timeField.getText()));
    variables.setSitesPercentage(Double.parseDouble(sitesField.getText()));
    variables.setBins(Integer.parseInt(nBinsField.getText()));

    return true;
  }

  //returns true if a new curve is added, false if not
  private boolean queryCurve()
  {
    boolean tmp;
    int fittingType;

    //Calculation types (must be the same as the values in CalculatorClass.java)
    final int GAMMA_C=1;
    final int GAMMA_EXPERIMENT=2;
    final int C_EXPERIMENT=3;
    final int EXPERIMENT=4;
  
    stopEditingAllFields();

    //Check that the input parameters are right
    if(!allParametersOK(true))
    {
      return false;
    }

    //Transform all the simulation parameters to numbers
    parameters = new SimulationVariables();
    if(fillSimulationVariables(parameters))
    {
        //Calculate the decay curve with a progress bar
        progressBar = new ProgressBar(this,CalculatorClass.DECAY_CURVE);
        if(progressBar!=null)
        {
          progressBar.setVisible(true);
        }
    }
    else
    {
      return false;
    }
    fittingType=parameters.getCalculation();

    if(isDistanceZero)
    {
      JOptionPane.showMessageDialog(this,"All the atomic distances are smaller than the cutoff\nPlease increase the number of unit cells",
                                      "All distances zero", JOptionPane.ERROR_MESSAGE);
      return false;
    }
    else if(isConversionZero)
    {
      JOptionPane.showMessageDialog(this,"The conversion rate is zero\nPlease increase the number of configurations",
                                      "Conversion rate zero", JOptionPane.ERROR_MESSAGE);
      return false;
    }
    else if(isInputTooLarge)
    {
      JOptionPane.showMessageDialog(null, "The format of the input file is not valid\n" +
                             "The maximum number of points in the experimental curve is " + MAX_POINTS,
                             "Wrong input format",JOptionPane.ERROR_MESSAGE);
      return false;
    }
    else if(isWrongInputFormat)
    {
      JOptionPane.showMessageDialog(null, "The format of the input file is not valid.\n" +
                             "The input file must contain two columns of\n" +
                             "real numbers separated by blank spaces.",
                             "Wrong input format",JOptionPane.ERROR_MESSAGE);
      return false;
    }
    else if(!isInputFileFound && (fittingType==GAMMA_EXPERIMENT || fittingType==C_EXPERIMENT || fittingType==EXPERIMENT))
    {
      JOptionPane.showMessageDialog(null, "The specified experimental file was not found",
                             "File not found",JOptionPane.ERROR_MESSAGE);
      return false;
    }
    else if(!enoughMemory)
    {
      JOptionPane.showMessageDialog(this,"There is not enough memory to perform this calculation\n" +
                                         "Please reduce the number of unit cells",
                                      "Not enough memory", JOptionPane.ERROR_MESSAGE);
      return false;
    }

    //We have to check that there were no errors and the curve was properly filled
    if(decayCurve!=null && !isDistanceZero && !isConversionZero && !isInputTooLarge && isInputFileFound && enoughMemory)
    {
      //This is needed because changing the next text fields fires a document event
      tmp=parameterFieldsChanged;
      //Fill the fitted parameters in the appropriate text boxes
      switch(parameters.getCalculation())
      {
        case CalculatorClass.GAMMA_EXPERIMENT:
          cField.setText(String.valueOf(parameters.getC()));
          cField.setCaretPosition(0);
          break;
        case CalculatorClass.C_EXPERIMENT:
          gammarField.setText(String.valueOf(parameters.getGamma()));
          gammarField.setCaretPosition(0);
          break;
        case CalculatorClass.EXPERIMENT:
          gammarField.setText(String.valueOf(parameters.getGamma()));
          cField.setText(String.valueOf(parameters.getC()));
          gammarField.setCaretPosition(0);
          cField.setCaretPosition(0);
          break;
      }
      if(parameters.getSitesPercentage()<1e-12)
      {
        cField.setText("0");
      }
      parameterFieldsChanged=tmp;

      return true;
    }
    // plot anyway in the case when the parameters are not fitted to a curve
    else if(!isInputFileFound && (fittingType!=GAMMA_EXPERIMENT && fittingType!=C_EXPERIMENT && fittingType!=EXPERIMENT))
    {
      return true;
    }
    else
    {
      return false;
    }
  }

  private void plotCurve()
  {
    double x[] = new double[MAX_POINTS];
    double y[] = new double [MAX_POINTS];

    //Check if the drawing frame is open, and if not, open one
    if(!isDrawingFrameOpen())
    {
      drawingFrame = new DrawingClass(this);
    }

    //If the experimental curve file has changed, check that it is right and add it to the plot
    if(experimentalFieldChanged)
    {
      experimentalFieldChanged=false;
      //Check that the file specified is valid, read it and store its information in the drawingFrame
      if(readExperimentalCurve(x,y))
      {
        drawingFrame.addExperimentalCurve(new CurveParameters(x,y,true));
      }
      //If there is no experimental file or it is not valid, an empty one is generated when the drawing frame is not displayed
      else if(!isDrawingFrameOpen())
      {
        drawingFrame.addExperimentalCurve(new CurveParameters(false));
      }
    }
    
    //Add the decay curve to the list of curves and plot all the curves
    drawingFrame.addCurve(new CurveParameters(decayCurve,false));
  }

  //return true if a file is read and false if not
  private boolean readExperimentalCurve(double[] time,double[] value)
  {
    int nPoints;
    double tmp;
    String line="";
    String[] data;
    double origin;

    int indexTime=0;
    int indexCurve=0;
    boolean timeRead;

    boolean originRead=false;
    double valueAtOrigin=1.0;

    //Read the experimental curve and store the information. We have to check the validity of the file
    //because we can have an experimental curve to plot (without being needed for the fitting)
    try
    {
      origin=Double.valueOf(timeOriginField.getText());
      nPoints=0;

      File experimentalFile = new File(experimentalCurveField.getText());
      FileReader experimentReader = new FileReader (experimentalFile);
      BufferedReader experimentBuffer = new BufferedReader(experimentReader);

      //Read the lines of the input file. If there are no more lines, an IOException is generated, but it is ignored
      line=experimentBuffer.readLine();
      while(line!=null)
      {
        //extract the different data from the line
        data=line.split(" ");
        timeRead=false;
        for(int i=0; i<data.length;i++)
        {
          if(!data[i].isEmpty())
          {
            if(!timeRead)
            {
              indexTime=i;
              timeRead=true;
            }
            else
            {
              indexCurve=i;
            }
          }
        }

        //check that the values are larger than the time origin and store them
        //the curve is normalized, with being the value at the origin equal to 1
        tmp=Double.parseDouble(data[indexTime]);
         
        if(tmp>=origin)
        {
          //store the value at the origin
          if(!originRead)
          {
            valueAtOrigin=Double.parseDouble(data[indexCurve]);
            value[nPoints]=1.0;
            originRead=true;
          }
          //We have to reescale everything to the origin provided by the user
          time[nPoints]=tmp-origin;
          value[nPoints]=Double.parseDouble(data[indexCurve])/valueAtOrigin;
          nPoints++;
          if(nPoints>MAX_POINTS)
          {
            JOptionPane.showMessageDialog(null,"The input file has too many input points",
                                            "File not valid", JOptionPane.ERROR_MESSAGE);
            return false;
          }
        }
        //read the next line in the file. We will take only one point out of five
        line=experimentBuffer.readLine();
      }

      experimentBuffer.close();
      experimentReader.close();
      experimentalFile=null;
    }
    //If the file name is empty or not found, ignore the experimental file
    catch (NullPointerException exception)
    {
      return false;
    }
    catch (FileNotFoundException exception)
    {
      return false;
    }
    catch (IOException exception)
    {
    }
    catch (ArrayIndexOutOfBoundsException exception)
    {
      JOptionPane.showMessageDialog(null, "The format of the input file is not valid",
                             "Wrong input format",JOptionPane.ERROR_MESSAGE);
      return false;
    }
    catch (NumberFormatException exception)
    {
      return false;
    }

    return true;
  }

//*********************Functions to validate data****************************************
//***************************************************************************************
//***************************************************************************************

  //returns 0 if all the Simulation Parameters are filled and right, 1 otherwise
  private boolean cellParametersOK(boolean displayError)
  {
    int dummyInt=0;
    long dummyLong[] = new long[3];
    double dummyDouble[] = new double[3];
    int column;

    try
    {
      dummyDouble[0]=Double.parseDouble(xField.getText());
      dummyDouble[1]=Double.parseDouble(yField.getText());
      dummyDouble[2]=Double.parseDouble(zField.getText());
       
      if(dummyDouble[0]<=0.0 || dummyDouble[1]<=0.0 || dummyDouble[2]<=0.0)
      {
        if(displayError)
        {
          JOptionPane.showMessageDialog(this,"Cell dimensions must be positive",
                                      "Error in 'Cell dimensions'", JOptionPane.ERROR_MESSAGE);
        }
        return false;
      }
    }
    catch(NumberFormatException exception)
    {
      if(displayError)
      {
        JOptionPane.showMessageDialog(this,"Cell dimensions must be real numbers",
                                       "Error in 'Cell dimensions'", JOptionPane.ERROR_MESSAGE);
      }
      return false;
    }
    try
    {
      dummyDouble[0]=Double.parseDouble(alphaField.getText());
      dummyDouble[1]=Double.parseDouble(betaField.getText());
      dummyDouble[2]=Double.parseDouble(gammaField.getText());
       
      if(dummyDouble[0]<=0.0  || dummyDouble[1]<=0.0  || dummyDouble[2]<=0.0 ||
         dummyDouble[0]>180.0 || dummyDouble[1]>180.0 || dummyDouble[2]>180.0)
      {
        if(displayError)
        {
          JOptionPane.showMessageDialog(this,"Cell angles must be between 0 and 180 degrees",
                                            "Error in 'Cell angles'", JOptionPane.ERROR_MESSAGE);
        }
        return false;
      }
    }
    catch(NumberFormatException exception)
    {
      if(displayError)
      {
        JOptionPane.showMessageDialog(this,"Cell angles must be real numbers",
                                            "Error in 'Cell angles'", JOptionPane.ERROR_MESSAGE);
      }
      return false;
    }
    try
    {
      dummyLong[0]=Long.parseLong(nxField.getText());
      dummyLong[1]=Long.parseLong(nyField.getText());
      dummyLong[2]=Long.parseLong(nzField.getText());
       
      if(dummyLong[0]<=0.0 || dummyLong[1]<=0.0 || dummyLong[2]<=0.0)
      {
        if(displayError)
        {
          JOptionPane.showMessageDialog(this,"Unit cells must be positive",
                                              "Error in 'Unit cells'", JOptionPane.ERROR_MESSAGE);
        }
        return false;
      }
    }
    catch(NumberFormatException exception)
    {
      if(displayError)
      {
        JOptionPane.showMessageDialog(this,"Unit cells must be integers",
                                              "Error in 'Unit cells'", JOptionPane.ERROR_MESSAGE);
      }
      return false;
    }
 
    //It is not necessary to check the periodic nor the orthorhombic fields, there can not be errors there
    //Chech again the number of atoms
    try
    {
      dummyInt=Integer.parseInt(numberOfAtomsField.getText());

      if(dummyInt<=0)
      {
        if(displayError)
        {
          JOptionPane.showMessageDialog(this,"The number of atoms must be a positive integer",
                                            "Error in the number of atoms'", JOptionPane.ERROR_MESSAGE);
        }
        return false;
      }
      //Check that we have the same lines in the positions table as number of atoms
      if(dummyInt!=atomPositionTable.getRowCount())
      {
        if(displayError)
        {
          JOptionPane.showMessageDialog(this,"Please specity the new atomic positions",
                                            "Error in the number of atoms'", JOptionPane.ERROR_MESSAGE);
        }
        return false;
      }
    }
    catch(NumberFormatException exception)
    {
      if(displayError)
      {
        JOptionPane.showMessageDialog(this,"The number of atoms must be an integer",
                                          "Error in the number of atoms'", JOptionPane.ERROR_MESSAGE);
        return false;
      }
    }
    //Check the positions table: only a number of atoms rows
    try
    {
      //Stop editing the table and save the data that is being edited
      column = atomPositionTable.getEditingColumn();

      if(column > -1)
      {
        TableCellEditor cellEditor = atomPositionTable.getColumnModel().getColumn(column).getCellEditor();

        if(cellEditor == null) 
        {
          cellEditor = atomPositionTable.getDefaultEditor(atomPositionTable.getColumnClass(column));
        }
        if(cellEditor != null) 
        { 
          cellEditor.stopCellEditing(); 
        }
      }

      for(int i=0;i<dummyInt;i++)
      {
        //read the table line by line
        dummyDouble[0]=Double.parseDouble(String.valueOf(atomPositionTable.getValueAt(i,1)));
        dummyDouble[1]=Double.parseDouble(String.valueOf(atomPositionTable.getValueAt(i,2)));
        dummyDouble[2]=Double.parseDouble(String.valueOf(atomPositionTable.getValueAt(i,3)));

        if(dummyDouble[0]<0.0 || dummyDouble[1]<0.0 || dummyDouble[2]<0.0 ||
           dummyDouble[0]>1.0 || dummyDouble[1]>1.0 || dummyDouble[2]>1.0 )
        {
          if(displayError)
          {
            JOptionPane.showMessageDialog(this,"The relative atomic positions must be in the interval 0-1",
                                          "Error in the atomic positions", JOptionPane.ERROR_MESSAGE);
          }
          return false;
        }
 
      }
    }
    catch(NumberFormatException exception)
    {
      if(displayError)
      {
        JOptionPane.showMessageDialog(this,"The atomic positions must be real numbers",
                                          "Error in the atomic positions'", JOptionPane.ERROR_MESSAGE);
      }
      return false;
    }
 
    return true;
  }

  //Check the model options
  private boolean modelOptionsOK()
  {
    //check the mechanism option
    if(String.valueOf(mechanismComboBox.getSelectedItem()).equalsIgnoreCase(""))
    {
      //If this field is not filled, but the % of acceptor sites is zero, it does not matter
      try
      {
        if(Double.parseDouble(sitesField.getText())>1e-20)
        {
          JOptionPane.showMessageDialog(this,"Please select one energy transfer mechanism",
                                                       "Error in 'Mechanism'", JOptionPane.ERROR_MESSAGE);
          return false;
        }
      }
      catch(NumberFormatException exception)
      {
      }
    }
    //check the interaction option
    if(String.valueOf(interactionComboBox.getSelectedItem()).equalsIgnoreCase("")&&Double.parseDouble(sitesField.getText())>1e-20)
    {
      //If this field is not filled, but the % of acceptor sites is zero, it does not matter
      try
      {
        if(Double.parseDouble(sitesField.getText())>1e-20)
        {
          JOptionPane.showMessageDialog(this,"Please select one energy transfer interaction",
                                                     "Error in 'Interaction'", JOptionPane.ERROR_MESSAGE);
          return false;
        }
      }
      catch(NumberFormatException exception)
      {
      }
    }
    //check the type of calculation
    if(String.valueOf(calculationTypeComboBox.getSelectedItem()).equalsIgnoreCase(""))
    {
      JOptionPane.showMessageDialog(this,"Please select one calculation type",
                                             "Error in 'User input'", JOptionPane.ERROR_MESSAGE);
      return false;
    }

    return true;
  }

  //Check the model parameters
  //This function can only be called after modelOptionOK has been called
  private boolean modelParametersOK()
  {
    double dummyDouble;

    //check every parameter only if it is required by the calculation type: check gammar
    if(String.valueOf(calculationTypeComboBox.getSelectedItem()).equalsIgnoreCase("\u03B3 + c") ||
       String.valueOf(calculationTypeComboBox.getSelectedItem()).equalsIgnoreCase("\u03B3 + experiment") )
    {
      try
      {
        dummyDouble=Double.parseDouble(gammarField.getText());
       
        if(dummyDouble<=0)
        {
          JOptionPane.showMessageDialog(this,"\u03B3 must be a positive number",
                                   "Error in '\u03B3'", JOptionPane.ERROR_MESSAGE);
          return false;
        }
      }
      catch(NumberFormatException exception)
      {
        JOptionPane.showMessageDialog(this,"For this calculation type, a real value of \u03B3 must be provided", 
                                    "Error in '\u03B3'",JOptionPane.ERROR_MESSAGE);
        return false;
      }
    }
    //check C
    if(String.valueOf(calculationTypeComboBox.getSelectedItem()).equalsIgnoreCase("\u03B3 + c") ||
       String.valueOf(calculationTypeComboBox.getSelectedItem()).equalsIgnoreCase("c + experiment") )
    {
      try
      {
        dummyDouble=Double.parseDouble(cField.getText());
       
        if(dummyDouble<=0)
        {
          JOptionPane.showMessageDialog(this,"C must be a positive number",
                                   "Error in 'C'", JOptionPane.ERROR_MESSAGE);
          return false;
        }
      }
      catch(NumberFormatException exception)
      {
        JOptionPane.showMessageDialog(this,"For this calculation type, a real value of C must be provided", 
                                    "Error in 'C'",JOptionPane.ERROR_MESSAGE);
        return false;
      }
    }
    //check the experimental curve and time origin. We will check later than the file exists and contains proper data
    if(String.valueOf(calculationTypeComboBox.getSelectedItem()).equalsIgnoreCase("\u03B3 + exp.") ||
       String.valueOf(calculationTypeComboBox.getSelectedItem()).equalsIgnoreCase("c + exp.") ||
       String.valueOf(calculationTypeComboBox.getSelectedItem()).equalsIgnoreCase("exp.") )
    {
      if(experimentalCurveField.getText().equalsIgnoreCase(""))
      {
       
        JOptionPane.showMessageDialog(this,"For this calculation type, an experimental curve must be provided", 
                                    "Error in 'Experimental curve'",JOptionPane.ERROR_MESSAGE);
        return false;
      }
      try
      {
        dummyDouble=Double.parseDouble(timeOriginField.getText());
      }
      catch(NumberFormatException exception)
      {
        JOptionPane.showMessageDialog(this,"The time origin must be a real number",
                                          "Error in 'Time origin'", JOptionPane.ERROR_MESSAGE);
        return false;
      }
      
    }
  
    return true;
  }

  //returns true if all the Simulation Parameters are filled and right, false otherwise
  private boolean simulationParametersOK()
  {
    long dummyLong;
    double dummyDouble;

    try
    {
      dummyLong=Long.parseLong(cyclesField.getText());
       
      if(dummyLong<=0)
      {
        JOptionPane.showMessageDialog(this,"Number of cycles must be a positive number",
                                 "Error in 'Number of cyles'", JOptionPane.ERROR_MESSAGE);
        return false;
      }
      if(dummyLong>Integer.MAX_VALUE)
      {
        JOptionPane.showMessageDialog(this,"Number of cycles must be lower than " + Integer.MAX_VALUE,
                                 "Error in 'Number of cyles'", JOptionPane.ERROR_MESSAGE);
        return false;
      }
    }
    catch(NumberFormatException exception)
    {
      JOptionPane.showMessageDialog(this,"Number of cycles must be an integer", 
                                  "Error in 'Number of cyles'",JOptionPane.ERROR_MESSAGE);
      return false;
    }
    try
    {
      dummyDouble=Double.parseDouble(timeField.getText());
    
      if(dummyDouble<=0.0)
      {
        JOptionPane.showMessageDialog(this,"Time step must be a positive number",
                                        "Error in 'Time step'", JOptionPane.ERROR_MESSAGE);
        return false;
      }
    }
    catch(NumberFormatException exception)
    {
      JOptionPane.showMessageDialog(this,"Time step must be a real number",
                                        "Error in 'Time step'", JOptionPane.ERROR_MESSAGE);
      return false;
    }
    try
    {
      dummyDouble=Double.parseDouble(sitesField.getText());

      if(dummyDouble<0.0||dummyDouble>=100.0)
      {
        JOptionPane.showMessageDialog(this,"% acceptor sites must be a number between 0 and 100",
                                    "Error in '% acceptor sites'", JOptionPane.ERROR_MESSAGE);
        return false;
      }
    }
    catch(NumberFormatException exception)
    {
      JOptionPane.showMessageDialog(this,"% acceptor sites must be a number between 0 and 100",
                                     "Error in '% acceptor sites'", JOptionPane.ERROR_MESSAGE);
      return false;
    }
    try
    {
      dummyLong=Long.parseLong(nBinsField.getText());

      if(dummyLong<=0)
      {
        JOptionPane.showMessageDialog(this,"Number of bins must be a positive number",
                                      "Error in 'Number of bins'", JOptionPane.ERROR_MESSAGE);
        return false;
      }
      if(dummyLong>Integer.MAX_VALUE)
      {
        JOptionPane.showMessageDialog(this,"Number of bins must be lower than " + Integer.MAX_VALUE,
                                 "Error in 'Number of bins'", JOptionPane.ERROR_MESSAGE);
        return false;
      }
    }
    catch(NumberFormatException exception)
    {
      JOptionPane.showMessageDialog(this,"Number of bins must be an integer",
                                      "Error in 'Number of bins'", JOptionPane.ERROR_MESSAGE);
      return false;
    }

    return true;
  } 


  private boolean allParametersOK(boolean displayError)
  {
    if(cellParametersOK(displayError)&&modelOptionsOK()&&modelParametersOK()&&simulationParametersOK())
    {
      return true;
    }
    else
    {
      return false;
    }
  } 

  //To stop editing the cell parameters
  private void stopCellEditingCells()
  {
    DefaultCellEditor editor;

    //size fields
    editor = new DefaultCellEditor(xField);
    editor.stopCellEditing();
    editor = new DefaultCellEditor(yField);
    editor.stopCellEditing();
    editor = new DefaultCellEditor(zField);
    editor.stopCellEditing();

    //angle fields
    editor = new DefaultCellEditor(alphaField);
    editor.stopCellEditing();
    editor = new DefaultCellEditor(betaField);
    editor.stopCellEditing();
    editor = new DefaultCellEditor(gammaField);
    editor.stopCellEditing();
 
    //unit cells fields
    editor = new DefaultCellEditor(nxField);
    editor.stopCellEditing();
    editor = new DefaultCellEditor(nyField);
    editor.stopCellEditing();
    editor = new DefaultCellEditor(nzField);
    editor.stopCellEditing();

    //Number of atoms
    editor = new DefaultCellEditor(numberOfAtomsField);
    editor.stopCellEditing();  
  }

  private void stopCellEditingParameters()
  {
    DefaultCellEditor editor;

    editor = new DefaultCellEditor(gammarField);
    editor.stopCellEditing();
    editor = new DefaultCellEditor(cField);
    editor.stopCellEditing();
    editor = new DefaultCellEditor(timeOriginField);
    editor.stopCellEditing();
    editor = new DefaultCellEditor(experimentalCurveField);
    editor.stopCellEditing();
   
    editor = new DefaultCellEditor(cyclesField);
    editor.stopCellEditing();
    editor = new DefaultCellEditor(sitesField);
    editor.stopCellEditing();
    editor = new DefaultCellEditor(timeField);
    editor.stopCellEditing();
    editor = new DefaultCellEditor(nBinsField);
    editor.stopCellEditing();
  }

  private void stopEditingAllFields()
  {
    stopCellEditingCells();
    stopCellEditingParameters();
  }

//**********************Functions to reset data******************************************
//***************************************************************************************
//***************************************************************************************

  private void resetSimulationFields()
  {
    cyclesField.setText(null);
    timeField.setText(null);
    sitesField.setText(null);
    nBinsField.setText(null);
  }

  private void resetCellFields()
  {
    xField.setText(null);
    yField.setText(null);
    zField.setText(null);

    alphaField.setText("90.0");
    betaField.setText("90.0");
    gammaField.setText("90.0");

    alphaField.setEditable(false);
    betaField.setEditable(false);
    gammaField.setEditable(false);

    nxField.setText(null);
    nyField.setText(null);
    nzField.setText(null);

    periodicBoundariesCheckBox.setSelected(true);
    orthorhombicCheckBox.setSelected(true);

    numberOfAtomsField.setText("");

    //delete all rows of the position table 
    for(int i=(atomPositionTable.getRowCount()-1);i>=0;i--)
    {
      positionsModel.removeRow(i);       
    }
  }

  private void resetModelOptions()
  {
    mechanismComboBox.setSelectedItem("");
    interactionComboBox.setSelectedItem("");
    calculationTypeComboBox.setSelectedItem("");
  }

  private void resetModelParametersFields()
  {
    gammarField.setText(null);
    cField.setText(null);
    timeOriginField.setText(null);
    experimentalCurveField.setText(null);
  }

  private void resetAllFields()
  {
    resetSimulationFields();
    resetCellFields();
    resetModelOptions();
    resetModelParametersFields();
  }


//************************Action listeners***********************************************
//***************************************************************************************
//***************************************************************************************

  //Unit cell listeners
  private class GeneralCellFieldListener implements DocumentListener
  {
    public void changedUpdate(DocumentEvent event)
    {
    }
    public void insertUpdate(DocumentEvent event)
    {
      cellFieldsChanged=true;
    }
    public void removeUpdate(DocumentEvent event)
    {
      cellFieldsChanged=true;
    }
  }

  private class PeriodicBoundariesListener implements ItemListener 
  {
    public void itemStateChanged(ItemEvent event)
    {
      cellFieldsChanged=true;
    }
  }
  private class OrthorhombicListener implements ItemListener
  {
    public void itemStateChanged(ItemEvent event)
    {  
      //If the orthorhombic check box is ticked, the angles are set to 90 degrees and are not allowed to change
      if(orthorhombicCheckBox.getSelectedObjects()!=null)
      {
        alphaField.setText("90.0");
        betaField.setText("90.0");
        gammaField.setText("90.0");
     
        alphaField.setEditable(false);
        betaField.setEditable(false);
        gammaField.setEditable(false);
      }
      else
      {
        alphaField.setEditable(true);
        betaField.setEditable(true);
        gammaField.setEditable(true);
      }
    }    

  }

  private class NumberOfAtomsListener implements DocumentListener
  {
    public void changedUpdate(DocumentEvent event)
    {
    }
    public void insertUpdate(DocumentEvent event)
    {
      refreshPositionTable(numberOfAtomsField.getText());
    }
    public void removeUpdate(DocumentEvent event)
    {
      refreshPositionTable(numberOfAtomsField.getText());
    }
  }

  private class PositionsModelListener implements TableModelListener
  {
    public void tableChanged(TableModelEvent event)
    {
      if(event.getColumn()>0 && event.getType()==event.UPDATE)
      {
        cellFieldsChanged=true;
      }  
    }
  }

  private class LoadListener implements ActionListener
  {
    public void actionPerformed(ActionEvent event)
    {
      readCellInfoFile();
    }
  }

  private class SaveListener implements ActionListener
  {
    public void actionPerformed(ActionEvent event)
    {
      writeCellInfoFile(true);
    }
  }

  private class NeighboursListener implements ActionListener
  {
    public void actionPerformed(ActionEvent event)
    {
      displayNeighbours();
    }
  }


  //model parameters listener
  private class GeneralParameterFieldListener implements DocumentListener
  {
    public void changedUpdate(DocumentEvent event)
    {
    }
    public void insertUpdate(DocumentEvent event)
    {
      parameterFieldsChanged=true;
    }
    public void removeUpdate(DocumentEvent event)
    {
      parameterFieldsChanged=true;
    }
  }
  private class ExperimentalFieldListener implements DocumentListener
  {
    public void changedUpdate(DocumentEvent event)
    {
    }
    public void insertUpdate(DocumentEvent event)
    {
      parameterFieldsChanged=true;
      experimentalFieldChanged=true;
    }
    public void removeUpdate(DocumentEvent event)
    {
      parameterFieldsChanged=true;
      experimentalFieldChanged=true;
    }
  }
  private class GeneralParameterItemListener implements ItemListener
  {
    public void itemStateChanged(ItemEvent event)
    {
      parameterFieldsChanged=true;
    }
  }

  private class BrowseButtonListener implements ActionListener
  {
    public void actionPerformed(ActionEvent event)
    {
      fillExperimentalFileName();
    }
  }

  //main buttons listeners
  private class RunListener implements ActionListener
  {
    public void actionPerformed(ActionEvent event)
    {
      if(queryCurve())
      {
        plotCurve();
      }
    }
  }

  private class ResetListener implements ActionListener
  {
    public void actionPerformed(ActionEvent event)
    {
      resetAllFields();
    }
  }


  private class ExitListener implements ActionListener
  {
    public void actionPerformed(ActionEvent event)
    {		
      if(writeCellInfoFile(false))
      {
        System.exit(0);
      }
    }
  }
}
