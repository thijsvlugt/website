import java.awt.Dialog;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import java.text.DecimalFormat;
import javax.swing.JOptionPane;
import javax.swing.SwingWorker;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;

//This class will only contain the cell parameters
public class CalculatorClass extends SwingWorker<Void, Void>
{ 

  final static int MAX_POINTS=10000;
  private final int BORDER=7;

  //Simulation type
  final static int NEIGHBOURS=0;
  final static int DECAY_CURVE=1;

  //Bar type
  final static int CONVERSION_RATE=0;
  final static int FITTING=1;
  final static int COPYING=2;

  //Mechanism types
  final static int SINGLE_TRANSFER=1;
  final static int COOPERATIVE=2;
  final static int ACCRETIVE=3;
  
  //Interaction types
  final static int DISTANCE=0;
  final static int DIPOLE_DIPOLE=1;
  final static int DIPOLE_QUADRUPOLE=2;
  final static int QUADRUPOLE_QUADRUPOLE=3;

  //Calculation types
  final static int GAMMA_C=1;
  final static int GAMMA_EXPERIMENT=2;
  final static int C_EXPERIMENT=3;
  final static int EXPERIMENT=4;
  
  //Cell parameters
  private double size[] = new double[3];
  private double angle[] = new double[3];
  private int n[] = new int[3];

  private boolean periodic;

  private int numberOfAtoms;
  private int totalAtoms;

  private double positions[][];
  private double allPositions[][];

  private double box[][] = new double[3][3];
  private double inverseBox[][] = new double[3][3];
  private double distances[][];

  //model
  private int mechanism;
  private int interaction;
  private int calculation;

  //model parameters
  private double gamma;
  private double c;
  private double origin;
  private String experimentalCurve;

  //simulation parameters
  private int cycles;
  private double step;
  private double sitePercentage;
  private int bins;

  //Other simulation parameters to be computed
  private double conversionRate[];
  private double finalGamma;
  private double finalC;

  //variables class to communicate with the variables in the main panel
  private SimulationVariables p = new SimulationVariables();
  private boolean useProgressBar = false;

  //Classes for the progress bar
  private ProgressBar progressBar;

  //Input and output
  private int simulationType;
  private String neighbourList;
  private double[][] decayCurve;

  //To control the GUI
  private MainPanel mainPanel;
  private double updateBarEvery;
  private int barType;

  //To control some possible errors
  private boolean isDistanceZero;
  private boolean isConversionZero;

  //Constructor
  public CalculatorClass(MainPanel parentContainer,SimulationVariables cell,int simulationParameter,ProgressBar bar)
  {
    mainPanel=parentContainer;
    simulationType=simulationParameter;
    p=cell;
    progressBar=bar;

    try
    {
      decayCurve = new double[p.getBins()][2];
    }
    catch(OutOfMemoryError error)
    {
      JOptionPane.showMessageDialog(parentContainer,"There is not enough memory for this calculation." + "\n" + "Please reduce the number of bins.",
                                     "Out of memory", JOptionPane.ERROR_MESSAGE);
      cancel(true);
      progressBar.closeBar();
      return;
    }

    addPropertyChangeListener(new DecayCurveListener());
  }

//*************************Class methods*************************************************
//***************************************************************************************
//***************************************************************************************

  //Fill the cell parameters
  private void fillCellVariables(SimulationVariables cell)
  {
    size=cell.getCellParameters();
  
    //Store the angles in radians
    angle=cell.getAngleParameters();
    angle[0]*=Math.PI/180.0;
    angle[1]*=Math.PI/180.0;
    angle[2]*=Math.PI/180.0;

    n=cell.getNParameters();
    periodic=cell.getPeriodic();
    numberOfAtoms=cell.getAtoms();
    
    positions = new double[numberOfAtoms][3];
    positions=cell.getPositions();

    totalAtoms=numberOfAtoms*n[0]*n[1]*n[2];
  }
  //Fill the simulation parameters
  private void fillOtherParameters(SimulationVariables cell)
  {
    mechanism=cell.getMechanism();
    interaction=cell.getInteraction();
    calculation=cell.getCalculation();

    //Parameters for the fitting
    gamma=cell.getGamma();
    c=cell.getC();
    finalGamma=gamma;
    finalC=c;
    experimentalCurve=cell.getExperimentalCurve();
    origin=cell.getOrigin(); 

    cycles=cell.getCycles();
    step=cell.getStep();
    //The percentage has to go in per unity
    sitePercentage=cell.getSitesPercentage()/100.0;
    bins=cell.getBins();
  }

  private void fillCellBox()
  {
    double tmp;

    tmp=(Math.cos(angle[0])-Math.cos(angle[2])*Math.cos(angle[1]))/Math.sin(angle[2]);

    box[0][0]=size[0]*n[0];  box[1][0]=size[1]*n[1]*Math.cos(angle[2]);  box[2][0]=size[2]*n[2]*Math.cos(angle[1]);
    box[0][1]=0.0;           box[1][1]=size[1]*n[1]*Math.sin(angle[2]);  box[2][1]=size[2]*n[2]*tmp;
    box[0][2]=0.0;           box[1][2]=0.0;                              box[2][2]=size[2]*n[2]*Math.sqrt(1.0-Math.cos(angle[1])*Math.cos(angle[1])-tmp*tmp);
  }

  private void fillInverseBox()
  {
    double r,d;
 
    //Calculate adjoint
    inverseBox[0][0]=box[1][1]*box[2][2]-box[1][2]*box[2][1];
    inverseBox[0][1]=box[0][2]*box[2][1]-box[0][1]*box[2][2];
    inverseBox[0][2]=box[0][1]*box[1][2]-box[0][2]*box[1][1]; 
    inverseBox[1][0]=box[1][2]*box[2][0]-box[1][0]*box[2][2];
    inverseBox[1][1]=box[0][0]*box[2][2]-box[0][2]*box[2][0];
    inverseBox[1][2]=box[0][2]*box[1][0]-box[0][0]*box[1][2];  
    inverseBox[2][0]=box[1][0]*box[2][1]-box[1][1]*box[2][0];
    inverseBox[2][1]=box[0][1]*box[2][0]-box[0][0]*box[2][1];
    inverseBox[2][2]=box[0][0]*box[1][1]-box[0][1]*box[1][0];    

    // calculate determinant
    d=box[0][0]*inverseBox[0][0]+box[1][0]*inverseBox[0][1]+box[2][0]*inverseBox[0][2];
    r=0.0;
    if(Math.abs(d)>0.0) r=1.0/d;

    // complete inverse matrix
    inverseBox[0][0]*=r; inverseBox[1][0]*=r; inverseBox[2][0]*=r;
    inverseBox[0][1]*=r; inverseBox[1][1]*=r; inverseBox[2][1]*=r;
    inverseBox[0][2]*=r; inverseBox[1][2]*=r; inverseBox[2][2]*=r;
  }

  private double[] convertFromABCtoXYZ(double t[])
  {
    double dr[] = new double[3];

    dr[0]=box[0][0]*t[0]+box[1][0]*t[1]+box[2][0]*t[2];
    dr[1]=box[0][1]*t[0]+box[1][1]*t[1]+box[2][1]*t[2];
    dr[2]=box[0][2]*t[0]+box[1][2]*t[1]+box[2][2]*t[2];
    return dr;
  }

  private double[] convertFromXYZtoABC(double t[])
  {
    double s[] = new double[3];

    s[0]=inverseBox[0][0]*t[0]+inverseBox[1][0]*t[1]+inverseBox[2][0]*t[2];
    s[1]=inverseBox[0][1]*t[0]+inverseBox[1][1]*t[1]+inverseBox[2][1]*t[2];
    s[2]=inverseBox[0][2]*t[0]+inverseBox[1][2]*t[1]+inverseBox[2][2]*t[2];
    return s;
  }

  private void fillAllPositions()
  {
    allPositions = new double[totalAtoms][3];
    int counter=0;

    for(int i=0;i<numberOfAtoms;i++)
    {
     for(int j=0;j<n[0];j++)
     {
       for(int k=0;k<n[1];k++)
       {
         for(int l=0;l<n[2];l++)
         {

           // convert to xyz (zeolite atoms are stored in xyz)
           allPositions[counter][0]=(positions[i][0]+j)/((double)n[0]);
           allPositions[counter][1]=(positions[i][1]+k)/((double)n[1]);
           allPositions[counter][2]=(positions[i][2]+l)/((double)n[2]);

           allPositions[counter]=convertFromABCtoXYZ(allPositions[counter]);
           counter++;
         }
      }
     }
    }
  }

  private void fillDistances(int model)
  {
    //Call the garbage collector to free all the memory we can
    System.gc();

    distances = new double[totalAtoms][totalAtoms];
    double d[] = new double[3];
    double dSqr,result=0.0;

    double halfBox[] = new double[3];
    double cutOffSqr;

    isDistanceZero=true;
    mainPanel.setDistanceZero(true);

    halfBox[0]=0.5*size[0]*n[0];
    halfBox[1]=0.5*size[1]*n[1];
    halfBox[2]=0.5*size[2]*n[2];

    cutOffSqr=Math.min(halfBox[0],halfBox[1]);
    cutOffSqr=Math.min(cutOffSqr,halfBox[2]);
    cutOffSqr*=cutOffSqr*(1-1e-12);

    for(int i=0;i<totalAtoms;i++)
    {
      //the distance of one atom to itself is zero
      distances[i][i]=0.0;

      for(int j=(i+1);j<totalAtoms;j++)
      {
        d[0]=allPositions[i][0]-allPositions[j][0];
        d[1]=allPositions[i][1]-allPositions[j][1];
        d[2]=allPositions[i][2]-allPositions[j][2];

        //Apply boundary conditions (or not)
        if(periodic)
        {
          //Convert from xyz to abc
          d=convertFromXYZtoABC(d);
          
          if(d[0]>0.5)
          {
            d[0]-=1.0;
          }
          else if(d[0]<-0.5)
          {
            d[0]+=1.0;
          }

          if(d[1]>0.5)
          {
            d[1]-=1.0;
          }
          else if(d[1]<-0.5)
          {
            d[1]+=1.0;
          }

          if(d[2]>0.5)
          {
            d[2]-=1.0;
          }
          else if(d[2]<-0.5)
          {
            d[2]+=1.0;
          }

          //Convert back to xyz
          d=convertFromABCtoXYZ(d);

        }
        dSqr=d[0]*d[0]+d[1]*d[1]+d[2]*d[2];

        //Check the cutoff
        if(dSqr<cutOffSqr)
        {
          switch(model)
          {
            case DISTANCE:
              result=Math.sqrt(dSqr);
              break;
            case DIPOLE_DIPOLE:
              result=1.0/(dSqr*dSqr*dSqr);
              break;
            case DIPOLE_QUADRUPOLE:
              result=1.0/(dSqr*dSqr*dSqr*dSqr);
              break;
            case QUADRUPOLE_QUADRUPOLE:  
              result=1.0/(dSqr*dSqr*dSqr*dSqr*dSqr);
              break;
          }
        }
        else
        {
          result=0.0;
        }

        if(isDistanceZero && result>1e-10)
        {
          isDistanceZero=false;
          mainPanel.setDistanceZero(false);
        }
         //Write the final distance to the distance vector     
        distances[i][j]=distances[j][i]=result;
      } //atoms j
    } //atoms i
  }

  public void calculateConversionRate()
  {

    conversionRate = new double[cycles];
    boolean isActiveAtom[] = new boolean[totalAtoms];
    double transferRate;
    int centralAtom;

    isConversionZero=true;
    mainPanel.setConversionZero(true);

    barType=CONVERSION_RATE;
    updateBarEvery=((double)cycles)/100.0;
    setProgress(0);

    //loop in the cycle
    for(int i=0;i<cycles;i++)
    {
      //If the percentage of sites is zero, the conversion is directly zero and we do not have to compute it
      if(sitePercentage>1e-12)
      {
        //Select the central atom at random
        centralAtom=(int)((double)totalAtoms*Math.random());

        //Select the acceptor Yb atoms at random
        for(int j=0;j<totalAtoms;j++)
        {
          if(Math.random()<sitePercentage && j!=centralAtom)
          {
            isActiveAtom[j]=true;
          }
          else
          {
            isActiveAtom[j]=false;
          }
        }
        //Distinguish between different mechanisms
        transferRate=0.0;
        switch(mechanism)
        {
          case COOPERATIVE:
            for(int j=0;j<totalAtoms;j++)
            {
              if(isActiveAtom[j] && j!=centralAtom)
              {
                for(int k=(j+1);k<totalAtoms;k++)
                {
                  if(isActiveAtom[k] && k!=centralAtom)
                  {
                    transferRate+=distances[centralAtom][j]*distances[centralAtom][k];
                  }
                }
              }
            }
            break; 
          case ACCRETIVE:
            for(int j=0;j<totalAtoms;j++)
            {
              if(isActiveAtom[j] && j!=centralAtom)
              {
                for(int k=(j+1);k<totalAtoms;k++)
                {
                  if(isActiveAtom[k] && k!=centralAtom)
                  {
                    transferRate+=distances[j][k]*(distances[centralAtom][k]+distances[centralAtom][j]);
                  }
                }
              }
            }
            break; 
          case SINGLE_TRANSFER:
            for(int j=0;j<totalAtoms;j++)
            {
              if(isActiveAtom[j] && j!=centralAtom)
              {
                transferRate+=distances[centralAtom][j];
              }
            }
            break; 
        }

        if(isConversionZero && transferRate>1e-10)
        {
          isConversionZero=false;
          mainPanel.setConversionZero(false);
        }
        //fill the conversion rate for this cycle
        conversionRate[i]=transferRate;
      }//if site percentage > 1e-12
      else
      {
        conversionRate[i]=0.0;
      }

      //set the progress of the calculation
      setProgress((int)((double)(i+1)/updateBarEvery));
    }

    //Perform the calculation also if the percentage of acceptor sites is zero
    if(isConversionZero && sitePercentage<1e-12)
    {
      isConversionZero=false;
      mainPanel.setConversionZero(false);
    }

  }

  private void fitExperimentalCurve(int fittingType)
  {

    File experimentalFile = new File(experimentalCurve);
    int nPoints;
    double time[] = new double[MAX_POINTS];
    double value[] = new double[MAX_POINTS];
    double tmp;
    String line="";
    String data[];

    int indexTime=0;
    int indexCurve=0;
    boolean timeRead;

    boolean originRead=false;
    double valueAtOrigin=1.0;

    double factor,deltaGamma,deltaC;
    double parameterGamma,parameterGammaOld;
    double parameterC,parameterCOld;
    double penaltyOld,penaltyNew;
    double valueNew;
    boolean gammaChanged=false;
    boolean cChanged=false;

    int MC_Moves = 100;
    int fitEvery = 5;
  
    nPoints=0;
    //Read the experimental curve and store the information
    try
    {
      FileReader experimentReader = new FileReader (experimentalFile);
      BufferedReader experimentBuffer = new BufferedReader(experimentReader);

      //Read the lines of the input file. If there are no more lines, an IOException is generated, but it is ignored
      line=experimentBuffer.readLine();
      while(line!=null)
      {
        //extract the different data from the line
        data=line.split(" ");
        timeRead=false;
        for(int i=0; i<data.length;i++)
        {
          if(!data[i].isEmpty())
          {
            if(!timeRead)
            {
              indexTime=i;
              timeRead=true;
            }
            else
            {
              indexCurve=i;
            }
          }
        }

        //check that the values are larger than the time origin and store them
        //the curve is normalized, with being the value at the origin equal to 1
        tmp=Double.parseDouble(data[indexTime]);
         
        if(tmp>=origin)
        {
          //store the value at the origin
          if(!originRead)
          {
            valueAtOrigin=Double.parseDouble(data[indexCurve]);
            value[nPoints]=1.0;
            originRead=true;
          }
          //We have to reescale everything to the origin provided by the user
          time[nPoints]=tmp-origin;
          value[nPoints]=Double.parseDouble(data[indexCurve])/valueAtOrigin;
          nPoints++;
          if(nPoints>MAX_POINTS)
          {
            JOptionPane.showMessageDialog(null,"The input file has too many input points",
                                            "File not valid", JOptionPane.ERROR_MESSAGE);
            return;
          }
        }
        //read the next line in the file. We will take only one point out of five
        line=experimentBuffer.readLine();
      }

      experimentBuffer.close();
      experimentReader.close();
      experimentalFile=null;
    }
    catch (FileNotFoundException exception)
    {
      mainPanel.setInputFileFound(false);
      return;
    }
    catch (NumberFormatException exception)
    {
      mainPanel.setWrongInputFormat(true);
      return;
    }
    catch (ArrayIndexOutOfBoundsException exception)
    {
      mainPanel.setInputTooLarge(true);
      return;
    }
    catch (IOException exception)
    {
    }
    mainPanel.setWrongInputFormat(false);
    mainPanel.setInputFileFound(true);
    mainPanel.setInputTooLarge(false);

    //case where no fitting is needed
    if(fittingType!=GAMMA_EXPERIMENT && fittingType!=C_EXPERIMENT && fittingType!=EXPERIMENT) return;

    //Select the starting from the input or at random
    if(gamma<=0.0)
    {
      parameterGamma=parameterGammaOld=Math.random()/100.0;
    }
    else
    {
      parameterGamma=parameterGammaOld=gamma;
    }
    if(c<=0.0)
    {
      parameterC=parameterCOld=10000.0*Math.random();
    }
    else
    {
      parameterC=parameterCOld=c;
    }
    //We will not fit the value of c in case the percentage of sites is zero
    if(sitePercentage<1e-12)
    {
      if(fittingType==EXPERIMENT)
      {
        parameterC=finalC=0.0;
        fittingType=C_EXPERIMENT;
      }
      else if(fittingType==GAMMA_EXPERIMENT)
      {
        //In this case, no fitting is needed
        finalC=0.0;
        return;
      }
    }

    deltaGamma=0.3*parameterGamma;
    deltaC=0.3*parameterC;

    //Instead of calculating the penalty in the first simulation, we set it to a very large value so that the first trial move will be accepted
    penaltyOld=1e100;
    //In the case of fitting gamma and c, more cycles are needed 
    if(fittingType==EXPERIMENT)
    {
      MC_Moves=MC_Moves*2;
    }

    //Prepare the progress bar
    barType=FITTING;
    setProgress(0);
    updateBarEvery=((double)MC_Moves)/100.0;

    //Run a Monte Carlo cycle to fit the data
    for(int cycleI=0;cycleI<MC_Moves;cycleI++)
    {
      tmp=Math.random();
      if(tmp<0.5)
        factor=1.0;
      else if(tmp<0.6)
        factor=0.1;
      else if(tmp<0.9)
        factor=0.01;
      else
        factor=0.001;

      //Change the parameters depending on the calculation type
      //We do not change the parameters in the first cycle, as we need to compute the penalty for the current parameters
      if(cycleI!=0)
      {
        switch(fittingType)
        {
          case GAMMA_EXPERIMENT:  //Change the value of c
            parameterCOld=parameterC;
            parameterC=Math.max(0.0,parameterC+2.0*(Math.random()-0.5)*deltaC*factor);     
            cChanged=true; 
            break;
          case C_EXPERIMENT:  //Change the value of gamma
            parameterGammaOld=parameterGamma;
            parameterGamma=Math.max(0.0,parameterGamma+2.0*(Math.random()-0.5)*deltaGamma*factor);      
            gammaChanged=true;
            break;
          case EXPERIMENT:  //Change the value of gamma or c
            if(Math.random()<0.3)
            {
              parameterGammaOld=parameterGamma;
              parameterGamma=Math.max(0.0,parameterGamma+2.0*(Math.random()-0.5)*deltaGamma*factor);      
              gammaChanged=true;
              cChanged=false;
            }
            else
            {
              parameterCOld=parameterC;
              parameterC=Math.max(0.0,parameterC+2.0*(Math.random()-0.5)*deltaC*factor);      
              gammaChanged=false;
              cChanged=true;
            }
            break;
        }
      }

      //Compute penalty
      penaltyNew=0.0;
      for(int i=0;i<nPoints;i++)
      {
        valueNew=0.0;
        //Distinguish between fitting c or fitting gamma
        switch(fittingType)
        {
          //We have to fit c
          case GAMMA_EXPERIMENT:
            for(int j=0;j<cycles;j++)
            {
              valueNew+=Math.exp(-time[i]*(gamma+conversionRate[j]*parameterC));
            }
            break;
          //we have to fit gamma
          case C_EXPERIMENT:
            for(int j=0;j<cycles;j++)
            {
              valueNew+=Math.exp(-time[i]*(parameterGamma+conversionRate[j]*c));
            }
            break;
          //we have to fit gamma and c
          case EXPERIMENT:
            for(int j=0;j<cycles;j++)
            {
              valueNew+=Math.exp(-time[i]*(parameterGamma+conversionRate[j]*parameterC));
            }
            break;
        }
        valueNew/=(double)cycles;

        penaltyNew+=Math.log(Math.max(1e-300,valueNew)/Math.max(1e-300,value[i]))*Math.log(Math.max(1e-300,valueNew)/Math.max(1e-300,value[i]));
      }

      //Accept or reject the new value of the parameter
      if(penaltyOld<penaltyNew)  //reject
      {
        if(gammaChanged) parameterGamma=parameterGammaOld;
        if(cChanged) parameterC=parameterCOld;
      }
      else  //accept
      {
        penaltyOld=penaltyNew;
      }

      setProgress((int)((cycleI+1.0)/updateBarEvery));
    }
    //Write the final parameter and update the main panel
    switch(fittingType)
    {
      case GAMMA_EXPERIMENT:
        finalC=parameterC;
        p.setC(finalC);
        break;
      case C_EXPERIMENT:
        finalGamma=parameterGamma;
        p.setGamma(finalGamma);
        break;
      case EXPERIMENT:
        finalGamma=parameterGamma;
        finalC=parameterC;
        p.setGamma(finalGamma);
        p.setC(finalC);
        break;
    }
  }

  private void calculateNeighbours()
  {
    int n[] = new int[totalAtoms];
    double d[] = new double[totalAtoms];
    double minValue,tmpValue;
    int tmpN;
    int index,validIndex;
    StringBuffer neighbours = new StringBuffer(500);
    boolean isInList;
    DecimalFormat formatter = new DecimalFormat("0.000000000000000");

    //If there is only one atom in the system, the list is empty
    if(totalAtoms<=1)
    {
      neighbourList="";
      return;
    }


    //Fill a temporary vector containing the distances between atom 0 and the rest of the atoms that are not zero
    //Counts only the distances that are not repeated, and stores the number of repeated distances9+
    validIndex=0;

    for(int i=0;i<totalAtoms;i++)
    {
      if(distances[0][i]>1e-5)
      {
        isInList=false;
        //Checks if this distance is already in the list, and if it is, sums one to the frequency of occurrence
        for(int j=0;j<validIndex;j++)
        {
          if(Math.abs(distances[0][i]-d[j])<1e-5)
          {
            n[j]++;
            isInList=true;
            break;
          }
        }
        //If this distance is not in the list, adds it to the list
        if(!isInList)
        {
          d[validIndex]=distances[0][i];
          n[validIndex]++;
          validIndex++;
        }
      }
    }
    //Sort the distances bewteen atom 0 and the rest of the atoms
    for(int i=0;i<validIndex;i++)
    {
      minValue=tmpValue=d[i];
      tmpN=n[i];
      index=i;
      for(int j=i+1;j<validIndex;j++)
      {
        //look for the minimum value
        if(d[j]<minValue)
        {
          minValue=d[j];
          index=j;
        }
      }
      //replace the values in i by the minimum value
      d[i]=d[index];
      d[index]=tmpValue;
      n[i]=n[index];
      n[index]=tmpN;
    }

    //Build the neighbours string
    for(int i=0;i<validIndex;i++)
    {
      if(d[i]<10.0)
      {
        neighbours.append("  ");
      }
      neighbours.append(formatter.format(d[i]));
      neighbours.append("\t");
      neighbours.append(n[i]);
      neighbours.append("\n");
    }

    neighbourList=neighbours.toString();
  }


  private void calculateDecayCurve()
  {
    double time,tmp;

    calculateConversionRate();

    //Stop the calculation if the conversion rate is zero
    if(isConversionZero) return;

    fitExperimentalCurve(calculation);

    barType=COPYING;
    setProgress(0);
    updateBarEvery=((double)bins)/100.0;

    for(int i=0;i<bins;i++)
    {
      time=(double)i*step;
      tmp=0.0;

      for(int j=0;j<cycles;j++)
      {
        tmp+=Math.exp(-time*(finalGamma+conversionRate[j]*finalC));
      }
      decayCurve[i][0]=time;
      decayCurve[i][1]=tmp/((double)cycles);
      setProgress((int)((i+1.0)/updateBarEvery));
    }

  }

//*******************Abstract and overwritten methods************************************
//***************************************************************************************
//***************************************************************************************

  protected Void doInBackground() throws Exception
  {
    if(simulationType==NEIGHBOURS)
    {
      progressBar.displayCounter(false);
      progressBar.changeMessage("Building neighbour list...");
      progressBar.pack();
    }

    //Fill variables. It is done here because it can take some time
    fillCellVariables(p);

    if(simulationType==DECAY_CURVE)
    {
      fillOtherParameters(p);
    }

    fillCellBox();
    fillInverseBox();
    fillAllPositions();

    if(simulationType==DECAY_CURVE)
    {
      fillDistances(interaction);
    }
    else
    {
      fillDistances(DISTANCE);
    }

    //Perform the calculation also if the percentage of acceptor sites is zero
    if(isDistanceZero && sitePercentage<1e-12)
    {
      isDistanceZero=false;
      mainPanel.setDistanceZero(false);
    }

    //perform the right type of calculation. Skip it if the distances are zero
    if(!isDistanceZero)
    {
      switch(simulationType)
      {
        case NEIGHBOURS:
          calculateNeighbours();
          break;
        case DECAY_CURVE:
          calculateDecayCurve();
          break;
      }
    }

    //This will close the progress bar and copy the output to the main panel
    if(!isDistanceZero && !isConversionZero)
    {
      switch(simulationType)
      {
        case NEIGHBOURS:
          progressBar.setNeighbours(neighbourList);
          break;
        case DECAY_CURVE:
          progressBar.setCurve(decayCurve);      
          break;
      }
    }

    mainPanel.setEnoughMemory(true);
    return null;
  }

  protected void done()
  {
    try
    {
      get();
    }
    catch(Exception exception)
    {
      mainPanel.setEnoughMemory(false);
      System.out.println("The exception here is:" + exception.getCause());
    }

    progressBar.setIndeterminateBar(true);
    progressBar.setVisible(false);
    progressBar.setModalityType(Dialog.ModalityType.MODELESS);
    progressBar.closeBar();
  }

//************************Helper methods*************************************************
//***************************************************************************************
//***************************************************************************************



//**************************Get methods**************************************************
//***************************************************************************************
//***************************************************************************************

  public String getNeighbours()
  {
    return neighbourList;
  }

  public double[][] getDecayCurve()
  {
    return decayCurve;
  }

//**************************Set methods**************************************************
//***************************************************************************************
//***************************************************************************************

//************************Event listeners************************************************
//***************************************************************************************
//***************************************************************************************

  private class DecayCurveListener implements PropertyChangeListener
  {
    public void propertyChange(PropertyChangeEvent event)
    {
      switch(simulationType)
      {
        case DECAY_CURVE:
          //Calculating the conversion rate
          if("progress".equals(event.getPropertyName()))
          {
            switch(barType)
            {
              case CONVERSION_RATE:
                progressBar.changeMessage("Calculating rates...");
                progressBar.pack();
                break;
              case FITTING:
                progressBar.changeMessage("Fitting parameters...");
                progressBar.pack();
                break;
              case COPYING: 
                progressBar.changeMessage("Calculating decay curve...");
                progressBar.pack();
                break;
            } 
            
            //reset the progress bar value
            progressBar.setIndeterminateBar(false);
            progressBar.setValueBar((Integer)event.getNewValue());
          }
          break;  
      }
    }
  }

}
