import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.WindowConstants;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFileChooser;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.awt.Container;
import java.awt.Color;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.util.LinkedList;
import java.util.Random;
import java.text.DecimalFormat;

public class DrawingClass extends JFrame implements WindowConstants 
{
  private static final long serialVersionUID = 1L;

  public int FRAME_WIDTH=600;
  public int FRAME_LENGTH=450;

  LinkedList<CurveParameters> curvesList = new LinkedList<CurveParameters>();

  //To communicate with the main panel
  private MainPanel mainPanel;
  private DrawingPanel drawingPanel;

  private boolean displayLegend=true;
  private boolean logarithmic=false;

  //Random number generator
  Random randomIndex = new Random();

  public DrawingClass(MainPanel parentFrame)
  {
    super ("Decay curve plot");

    mainPanel=parentFrame;
    parentFrame.setDrawingFrameOpen(true);
 
    drawingPanel = new DrawingPanel(this, curvesList);

    Container thisFrame = getContentPane();

    this.setDefaultCloseOperation(this.DO_NOTHING_ON_CLOSE);

    //Create the menu and the main panel for the main frame
    DrawingMenu drawingMenu = new DrawingMenu();
    setJMenuBar(drawingMenu);
		
    //Add a window listener to close the main frame when requested
    this.addWindowListener(new CloseListener());

    this.setSize(FRAME_WIDTH,FRAME_LENGTH);
    this.add(drawingPanel);

    setVisible(true);
  }	


//**************************Class methods************************************************
//***************************************************************************************
//***************************************************************************************

  public void addCurve(CurveParameters curve)
  {
    CurveParameters experimentalCurve;

    try
    {
      //If the list is empty and the curve to add is not experimental, leave empty the first register of the list
      if(curvesList.isEmpty() && !curve.isExperimental())
      {
        curvesList.add(new CurveParameters(false));
      }

      //If we already have 10 curves plotted, delete them (not the experimental curve) and plot the new one on its own
      if(curvesList.size()>10)
      {
        experimentalCurve=curvesList.get(0);
        clearAllCurves();
        addExperimentalCurve(experimentalCurve);
      }
 
      if(curvesList.add(curve))
      {
        //set the color of the curve
        if(curvesList.size()<CurveParameters.colors.length)
        {
          curvesList.getLast().setColor(CurveParameters.colors[curvesList.size()-1]);
        }
        //If the defined colors are all taken, generate one color at random
        else
        {
          curvesList.getLast().setColor(new Color(randomIndex.nextInt(256),randomIndex.nextInt(256),randomIndex.nextInt(256)));
        }
      }
      else
      {
        JOptionPane.showMessageDialog(this,"This curve could not be added to the Plot",
                                 "Error adding curve", JOptionPane.ERROR_MESSAGE);
      }
    }
    catch(Exception exception)
    {
      JOptionPane.showMessageDialog(this,"This curve could not be added to the plot",
                               "Error adding curve", JOptionPane.ERROR_MESSAGE);
      return;
    }

    drawingPanel.repaint();
  }
  public void addExperimentalCurve(CurveParameters curve)
  {
    try
    {
      if(!curvesList.isEmpty())
      {
        curvesList.remove(0);
      }

      //add the curve with the right color
      curvesList.add(0,curve);
      curvesList.getFirst().setColor(CurveParameters.colors[0]);
    }
    catch(Exception exception)
    {
      JOptionPane.showMessageDialog(this,"Error adding curve",
                               "The experimental curve could not be added to the plot", JOptionPane.ERROR_MESSAGE);
      return;
    }
  }

  private void resetLegend()
  {
    //Change the status of display legend
    if(displayLegend)
    {
      displayLegend=false;
    }
    else
    {
      displayLegend=true;
    }

    //Call the drawing panel to plot the curve or not
    drawingPanel.displayLegend(displayLegend);
  }

  private void resetLogarithmic()
  {
    //Change the type of the Y axis
    if(logarithmic)
    {
      logarithmic=false;
    }
    else
    {
      logarithmic=true;
    }

    //Call the drawing panel to plot the curve in the appropriate type of axis
    drawingPanel.drawLogarithmicScale(logarithmic);
  }

  private void saveDecayCurve(CurveParameters curve,String name)
  {
    int saveFileResult;
    int nPoints;
    File decayCurveFile = new File(name);
    DecimalFormat formatter = new DecimalFormat("0.000000000000000");

    JFileChooser myFileChooser = new JFileChooser("./ComputedDecayCurves");
    myFileChooser.setFileSelectionMode(myFileChooser.FILES_ONLY);
    myFileChooser.setSelectedFile(decayCurveFile);

    saveFileResult=myFileChooser.showSaveDialog(this);

    //We exit this method if the user press cancel
    if (saveFileResult==JFileChooser.CANCEL_OPTION)
    {
      return;
    }

    //store the file chosen by the user
    decayCurveFile=myFileChooser.getSelectedFile();

    //Check that the file name is valid
    if ((decayCurveFile==null)||(decayCurveFile.getName().equals("")))
    {
      JOptionPane.showMessageDialog(this,"File name not valid",
                                      "File not valid", JOptionPane.ERROR_MESSAGE);
    }
    else
    {
      try
      {
        //Create an output buffer for the file
        FileOutputStream curveStream = new FileOutputStream(decayCurveFile);
        PrintWriter curveWriter = new PrintWriter(curveStream);

        //We write in the output the information in the right format
        nPoints=curve.getLength();
        for(int i=0;i<nPoints;i++)
        {
          curveWriter.println(formatter.format(curve.getXAtIndex(i)) + "\t" + formatter.format(curve.getYAtIndex(i)));
        }

        curveWriter.close();
        curveStream.close();
        decayCurveFile=null;
      }
      catch (IOException excepcion)
      {
        JOptionPane.showMessageDialog(this,"The selected file could not be saved",
                                     "Save file error", JOptionPane.ERROR_MESSAGE);
        return;
      }

    } 
  }

  private void resetPanelView()
  {
    drawingPanel.resetView();
  }

  private void clearAllCurves()
  {
    mainPanel.setExperimentalFieldChanged(true);
    curvesList.clear();
    drawingPanel.repaint();
  }

  private void decideClosing()
  {
    mainPanel.setDrawingFrameOpen(false);
    mainPanel.setExperimentalFieldChanged(true);
    this.dispose();
  }
	
//****************************Menu class*************************************************
//***************************************************************************************
//***************************************************************************************

  private class DrawingMenu extends JMenuBar
  {
    private static final long serialVersionUID = 1L;

    //Class constructor
    public DrawingMenu()
    {
      //File menu
      JMenu file = new JMenu ("File");
      file.setMnemonic('F');

      //File menu items
      JMenuItem saveLast = new JMenuItem("Save last");
      JMenuItem saveAll  = new JMenuItem("Save all"); 
      JMenuItem exit     = new JMenuItem("Exit");

      saveLast.setMnemonic('S');
      saveAll.setMnemonic('A');
      exit.setMnemonic('X');

      saveLast.addActionListener(new SaveLastListener());
      saveAll.addActionListener(new SaveAllListener());
      exit.addActionListener(new ExitListener());

      file.add(saveLast);
      file.add(saveAll);
      file.addSeparator();
      file.add(exit);

      //View menu
      JMenu view = new JMenu ("View");
      view.setMnemonic('V');

      //View menu items
      JMenuItem resetView = new JMenuItem("Reset view");
      JMenuItem clearAll  = new JMenuItem("Clear all"); 
      JCheckBoxMenuItem legend = new JCheckBoxMenuItem("Legend",true);
      JCheckBoxMenuItem logarithmic = new JCheckBoxMenuItem("Logarithmic scale",false);

      resetView.setMnemonic('R');
      clearAll.setMnemonic('C');
      legend.setMnemonic('L');
      logarithmic.setMnemonic('G');

      resetView.addActionListener(new ResetViewListener());
      clearAll.addActionListener(new ClearAllListener());
      legend.addItemListener(new LegendListener());
      logarithmic.addItemListener(new LogarithmicListener());

      view.add(resetView);
      view.add(clearAll);
      view.addSeparator();
      view.add(legend);
      view.add(logarithmic);

      //Add menus to the menu bar
      this.add(file);
      this.add(view);

      this.setVisible(true);
    }
  }

//******************Action listeners of the menu*****************************************
//***************************************************************************************
//***************************************************************************************

  private class SaveLastListener implements ActionListener
  {
    public void actionPerformed(ActionEvent event)
    {
      if(curvesList.size()<2)
      {
        return;
      }
      saveDecayCurve(curvesList.getLast(),""); 
    }
  }

  private class SaveAllListener implements ActionListener
  {
    public void actionPerformed(ActionEvent event)
    {
      if(curvesList.size()<2)
      {
        return;
      }
      
      for(int i=1;i<curvesList.size();i++)
      {
        saveDecayCurve(curvesList.get(i),"simulation" + i);
      }
    }
  }

  private class LegendListener implements ItemListener
  {
    public void itemStateChanged(ItemEvent event)
    {
      resetLegend();
    }
  }

  private class LogarithmicListener implements ItemListener
  {
    public void itemStateChanged(ItemEvent event)
    {
      resetLogarithmic();
    }
  }

  private class ResetViewListener implements ActionListener
  {
    public void actionPerformed(ActionEvent event)
    {
      resetPanelView();
    }
  }

  private class ClearAllListener implements ActionListener
  {
    public void actionPerformed(ActionEvent event)
    {
      clearAllCurves();
    }
  }

  private class ExitListener implements ActionListener
  {
    public void actionPerformed(ActionEvent event)
    {
      decideClosing();
    }
  }


//**************************Get methods**************************************************
//***************************************************************************************
//***************************************************************************************


//************************Action listeners***********************************************
//***************************************************************************************
//***************************************************************************************

  private class CloseListener extends WindowAdapter
  {
    public void windowClosing(WindowEvent e)
    {
      decideClosing();
    }
  }

}
