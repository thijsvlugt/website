import java.awt.Color;
import java.awt.Graphics;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;
import javax.swing.BorderFactory;
import java.util.LinkedList;
import java.text.DecimalFormat;

public class DrawingPanel extends JPanel 
{
  private static final long serialVersionUID = 1L;

  private final int BORDER=7; 
  private final int XAXIS_BORDER=40;
  private final int YAXIS_BORDER=50;
  private final int WIDTH=2;
  private final int TICKS=4;

  //To calculate what part of the graphics has to be shown
  private double minX,maxX,minY,maxY;
  private boolean zoomed=false;

  //To communicate with the main drawing frame
  DrawingClass parentFrame;
  LinkedList<CurveParameters> curves;

  //To deal with mouse events
  private boolean mousePressed=false;
  private boolean mouseReleased=false;
  private int mousePressedAtX;
  private int mousePressedAtY;
  private int mouseDraggedAtX;
  private int mouseDraggedAtY;
  private int mouseReleasedAtX;
  private int mouseReleasedAtY;

  //Position of the legend
  private int legendX;
  private int legendY;
  private int widthLegend;
  private int heightLegend;
  private boolean translatedLegend=false;
  private boolean isTranslated=false;
  private int oldWidth,oldHeight;
  private boolean displayLegend=true;

  //Logarithmic scale
  private boolean logarithmicAxis=false;
  private double minYLog;

  //constructor of the class with the parameters that give the size of the panel
  public DrawingPanel(DrawingClass mainFrame, LinkedList<CurveParameters> curveList)
  {
    parentFrame=mainFrame;
    curves=curveList;

    setBorder(BorderFactory.createEmptyBorder(BORDER,BORDER,BORDER,BORDER));
    setBackground(Color.WHITE);

    addMouseListener(new ZoomTranslateListener());
    addMouseMotionListener(new ZTListener());

  }

//**************************Class methods************************************************
//***************************************************************************************
//***************************************************************************************

  //Function to plot all the curves. Relative coordinates are used, so we can resize the panel and still plot properly
  public void paintComponent(Graphics g)
  {
    //call paintComponent from the parent Component class to ensure the panel displays correctly
    super.paintComponent(g);

    drawAxis(g);
    drawCurves(g);


    if(displayLegend)
    {
      //relocate the legend if the window size changes
      if(isTranslated)
      {
        legendX=(int)(legendX*((double)getWidth()/(double)oldWidth));
        legendY=(int)(legendY*((double)getHeight()/(double)oldHeight));

        if(legendX<=0) legendX=1;
        if(legendY<=0) legendY=1;

        oldWidth=getWidth();
        oldHeight=getHeight();
      }

      drawLegend(g);
    }

    if(mousePressed)
    {
      if(translatedLegend)
      {
        drawTranslatedArea(g);
      }
      else
      {
        drawZoomArea(g);
      }
    }
  }

  private void drawAxis(Graphics gg)
  {
    double N_XLABELS=5.0;
    double N_YLABELS=5.0;
    int tickLabelsXEvery, tickLabelsYEvery;
    int index;
    CurveParameters tmp;

    DecimalFormat formatX = new DecimalFormat("0.000000000000000");
    DecimalFormat formatY = new DecimalFormat("0.000000000000000");
    double labelXEvery;
    double labelYEvery;   
    double labelYLog[] = new double[(int)(N_YLABELS + 1)];
    int size,size2;
    String dummy;

    //x and y axis, respectively
    gg.drawLine(2*XAXIS_BORDER,getHeight()-YAXIS_BORDER,getWidth()-XAXIS_BORDER,getHeight()-YAXIS_BORDER);
    gg.drawLine(2*XAXIS_BORDER-1,getHeight()-YAXIS_BORDER+1,getWidth()-XAXIS_BORDER+1,getHeight()-YAXIS_BORDER+1);
    gg.drawLine(2*XAXIS_BORDER,getHeight()-YAXIS_BORDER,2*XAXIS_BORDER,YAXIS_BORDER);
    gg.drawLine(2*XAXIS_BORDER-1,getHeight()-YAXIS_BORDER,2*XAXIS_BORDER-1,YAXIS_BORDER);

    //Also closing in a rectangle
    gg.drawLine(2*XAXIS_BORDER,YAXIS_BORDER,getWidth()-XAXIS_BORDER,YAXIS_BORDER);
    gg.drawLine(2*XAXIS_BORDER-1,YAXIS_BORDER-1,getWidth()-XAXIS_BORDER+1,YAXIS_BORDER-1);
    gg.drawLine(getWidth()-XAXIS_BORDER,getHeight()-YAXIS_BORDER,getWidth()-XAXIS_BORDER,YAXIS_BORDER);
    gg.drawLine(getWidth()-XAXIS_BORDER+1,getHeight()-YAXIS_BORDER,getWidth()-XAXIS_BORDER+1,YAXIS_BORDER);

    //draw tick labels and reference lines. We will paint N_LABELS labels in every axis
    tickLabelsXEvery=(int)((getWidth()-3*XAXIS_BORDER)/N_XLABELS);
    tickLabelsYEvery=(int)((getHeight()-2*YAXIS_BORDER)/N_YLABELS);

    gg.setColor(Color.LIGHT_GRAY);

    for(int i=1;i<N_XLABELS;i++)
    {
      gg.drawLine(2*XAXIS_BORDER+tickLabelsXEvery*i,getHeight()-YAXIS_BORDER+TICKS,2*XAXIS_BORDER+tickLabelsXEvery*i,YAXIS_BORDER+2);
    }

    for(int i=1;i<N_YLABELS;i++)
    {
      gg.drawLine(2*XAXIS_BORDER-TICKS,getHeight()-YAXIS_BORDER-tickLabelsYEvery*i,getWidth()-XAXIS_BORDER-2,getHeight()-YAXIS_BORDER-tickLabelsYEvery*i);
    }

    //Calculate the portion of the curves that have to be plotted in the case there is no zoom
    if(!zoomed)
    {
      //Ensure that the axis are plotted properly even if there are no curves to plot
      if(curves.size()==0)
      {
        maxY=1.0;
        minY=0.0;
        maxX=10000;
        minX=0.0;
        minYLog=0.1;        
      }
      else
      { 
        maxY=1.0;
        minY=0.0;
        maxX=0.0;
        minX=0.0;
        minYLog=1.0;

        for(int i=0;i<curves.size();i++)
        {
          tmp=curves.get(i);
          index=tmp.getLength();
          if(tmp.isDrawable())
          {
    	    maxX=Math.max(maxX,tmp.getXAtIndex(index));
//            for(int j=index-100;j<=index;j++)
            for(int j=index;j<=index;j++)
            {
              minYLog=Math.min(minYLog,tmp.getYAtIndex(j));
            }
          }
        }
      }
    }

    //Select the right format for the x labels
    if(maxX-minX<0.05)
    {
      formatX = new DecimalFormat("0.0E0");
    }
    else if(maxX-minX<10)
    {
      formatX = new DecimalFormat("0.##");
    }
    else if(maxX-minX<100)
    {
      formatX = new DecimalFormat("#0.#");
    }
    else if(maxX-minX<=10000.0)
    {
      formatX = new DecimalFormat("####");
    }
    else
    {
      formatX = new DecimalFormat("0.0E0");
    }

    //Decide what labels to print
    if(logarithmicAxis)
    {
      for(int i=0;i<=N_YLABELS;i++)
      {
        if(i==0)
        {
          labelYLog[0]=minYLog;
        }
        else
        {
          labelYLog[i]=Math.pow(10.0,(double)i*Math.log10((maxY/minYLog))/N_YLABELS)*minYLog;
        }
      }
    }
    labelXEvery=(maxX-minX)/N_XLABELS;
    labelYEvery=(maxY-minY)/N_YLABELS;

    gg.setColor(Color.BLACK);
    gg.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
    FontMetrics metrics = gg.getFontMetrics();

    size2=metrics.getHeight();
    //Axis label x
    for(int i=0;i<=N_XLABELS;i++)
    {
      //We print only one zero in case x starts in zero
      if(i==0 && minX<1e-10)
      {
        size=metrics.stringWidth("0");
        gg.drawString("0",(int)(2*XAXIS_BORDER-size*0.5),getHeight()-YAXIS_BORDER+TICKS+size2);
        continue;
      }
      dummy=formatX.format(minX+i*labelXEvery);
      size=metrics.stringWidth(dummy);
      gg.drawString(dummy,(int)(2*XAXIS_BORDER+tickLabelsXEvery*i-size*0.5),getHeight()-YAXIS_BORDER+TICKS+size2);
    }
    
    size=metrics.stringWidth("time");
    gg.drawString("time",(int)(2*XAXIS_BORDER+(getWidth()-3*XAXIS_BORDER-size)*0.5),getHeight()-YAXIS_BORDER+TICKS+2*size2);

    //Axis label y 
    for(int i=0;i<=N_YLABELS;i++)
    {
      //We print only one zero in case x starts in zero
      if(i==0 && minY<1e-15 && !logarithmicAxis)
      {
        size=metrics.stringWidth("0");
        gg.drawString("0",2*XAXIS_BORDER-size-2*TICKS,getHeight()-YAXIS_BORDER);
      }
      else
      {
        if(logarithmicAxis)
        {
          dummy=setYLogFormat(labelYLog[i]);
        }
        else
        {
          dummy=setYLogFormat(minY+i*labelYEvery);
        }
        size=metrics.stringWidth(dummy);
        gg.drawString(dummy,2*XAXIS_BORDER-size-2*TICKS,getHeight()-YAXIS_BORDER-tickLabelsYEvery*i);
      }
    }
    
    size=metrics.stringWidth("I (t)");
    gg.drawString("I (t)",2*XAXIS_BORDER-3*size,(int)(YAXIS_BORDER+(getHeight()-2*YAXIS_BORDER)*0.5));

    gg.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
    size=metrics.stringWidth("Decay curve");
    gg.drawString("Decay curve",(int)((getWidth()-size)*0.5),(int)((YAXIS_BORDER+size2)*0.5));

    gg.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));

  }

  private String setYLogFormat(double number)
  {
    DecimalFormat formatY = new DecimalFormat("0.000000000000000");

    if(number<0.05)
    {
      formatY = new DecimalFormat("0.0E0");
    }
    else if(number<10)
    {
      formatY = new DecimalFormat("0.##");
    }

    return formatY.format(number);
  }

  private void drawCurves(Graphics gg)
  {
    CurveParameters tmp;
    double XtoPixel;
    double YtoPixel;
    double YLogtoPixel;

    int pixelX[];
    int pixelY[];

    int nPoints;
    int pointsInDisplayArea;
    double x,y;
    int height;

    //get the conversion factor from amstrongs to pixels and from intensity to pixels
    height=getHeight();
    XtoPixel=((double)(getWidth()-3*XAXIS_BORDER))/(maxX-minX);
    YtoPixel=((double)(height-2*YAXIS_BORDER))/(maxY-minY);
    YLogtoPixel=((double)(height-2*YAXIS_BORDER))/Math.log10(maxY/minYLog);

    //plot the curves one by one
    for(int i=0;i<curves.size();i++)
    {
      tmp=curves.get(i);
      nPoints=tmp.getLength();
      pointsInDisplayArea=0;
      gg.setColor(tmp.getColorID());    

      pixelX = new int[nPoints];
      pixelY = new int[nPoints];
      
      //Distinguish between experimental and simulation curve
      if(tmp.isExperimental() && tmp.isDrawable())
      {
        for(int j=0;j<nPoints;j++)
        {
          x=tmp.getXAtIndex(j);
          y=tmp.getYAtIndex(j);

          //Plot only the points that lay in the region that must be displayed
          if(x>=minX && x<=maxX && y>=minY && y<=maxY)
          {
            if(logarithmicAxis)
            {
              if(x>1e-10)
              {
                gg.fillOval((int)(2*XAXIS_BORDER+(x-minX)*XtoPixel-1),(int)(height-YAXIS_BORDER-Math.log10(y/minYLog)*YLogtoPixel-1),2,2);
              }
            }
            else
            {
              gg.fillOval((int)(2*XAXIS_BORDER+(x-minX)*XtoPixel-1),(int)(height-YAXIS_BORDER-(y-minY)*YtoPixel-1),2,2);
            }
          }
        }
      }
      else
      {
        for(int j=0;j<nPoints;j++)
        {
          x=tmp.getXAtIndex(j);
          y=tmp.getYAtIndex(j);

          //Consider only the points that lay in the region that must be displayed
          if(x>=minX && x<=maxX && y>=minY && y<=maxY)
          {
            if(logarithmicAxis)
            {
              if(y>1e-10)
              {
                pixelX[pointsInDisplayArea]=(int)(2*XAXIS_BORDER+(x-minX)*XtoPixel);
                pixelY[pointsInDisplayArea]=(int)(height-YAXIS_BORDER-Math.log10(y/minYLog)*YLogtoPixel);
                pointsInDisplayArea++;
              }
            }
            else
            {
              pixelX[pointsInDisplayArea]=(int)(2*XAXIS_BORDER+(x-minX)*XtoPixel);
              pixelY[pointsInDisplayArea]=(int)(height-YAXIS_BORDER-(y-minY)*YtoPixel);
              pointsInDisplayArea++;
            }
          }
        }
        gg.drawPolyline(pixelX,pixelY,pointsInDisplayArea);
      }
    }
  }

  private void drawZoomArea(Graphics gg)
  {
    int firstPointX,firstPointY,width,height;

    if(mouseDraggedAtX-mousePressedAtX>0)
    {
      firstPointX=mousePressedAtX;
    }
    else
    {
      firstPointX=mouseDraggedAtX;
    }
    if(mouseDraggedAtY-mousePressedAtY>0)
    {
      firstPointY=mousePressedAtY;
    }
    else
    {
      firstPointY=mouseDraggedAtY;
    }

    width=Math.abs(mouseDraggedAtX-mousePressedAtX);
    height=Math.abs(mouseDraggedAtY-mousePressedAtY);

    //Draw a square of the right size and color
    gg.setColor(Color.BLACK);
    gg.drawRect(firstPointX,firstPointY,width,height);

  }

  private void calculateZoomArea()
  {
    int firstPointX,firstPointY,width,height;
    int secondPointX,secondPointY;
    double pixelToX,pixelToY;
    double pixelToYLog;
    double tmp;

    if(mouseReleasedAtX-mousePressedAtX>0)
    {
      firstPointX=mousePressedAtX;
    }
    else
    {
      firstPointX=mouseReleasedAtX;
    }
    //The point with lower value of y has a larger pixel value
    if(mouseReleasedAtY-mousePressedAtY>0)
    {
      firstPointY=mouseReleasedAtY;
    }
    else
    {
      firstPointY=mousePressedAtY;
    }

    width=Math.abs(mouseReleasedAtX-mousePressedAtX);
    height=Math.abs(mouseReleasedAtY-mousePressedAtY);
  
    secondPointX=firstPointX+width;
    secondPointY=firstPointY-height;


    //Recalculate the zoom area. The minimum zoom area is 6x6 pixels
    if(mouseReleased && width>5 && height>5)
    {
      zoomed=true;

      //Zoom only the region inside the plot
      if(firstPointX<2*XAXIS_BORDER) firstPointX=2*XAXIS_BORDER;
      if(firstPointX>getWidth()-XAXIS_BORDER) firstPointX=getWidth()-XAXIS_BORDER;
      if(firstPointY<YAXIS_BORDER) firstPointY=YAXIS_BORDER;
      if(firstPointY>getHeight()-YAXIS_BORDER) firstPointY=getHeight()-YAXIS_BORDER;

      if(secondPointX<2*XAXIS_BORDER) secondPointX=2*XAXIS_BORDER;
      if(secondPointX>getWidth()-XAXIS_BORDER) secondPointX=getWidth()-XAXIS_BORDER;
      if(secondPointY<YAXIS_BORDER) secondPointY=YAXIS_BORDER;
      if(secondPointY>getHeight()-YAXIS_BORDER) secondPointY=getHeight()-YAXIS_BORDER;

      pixelToX=(maxX-minX)/((double)(getWidth()-3*XAXIS_BORDER));
      pixelToY=(maxY-minY)/((double)(getHeight()-2*YAXIS_BORDER));
      pixelToYLog=Math.log10(maxY/minYLog)/((double)(getHeight()-2*YAXIS_BORDER));

      //Calculate the new max and min x e y that have to be displayed. 
      tmp=minX;
      minX=(double)(firstPointX-2*XAXIS_BORDER)*pixelToX+tmp;
      maxX=(double)(secondPointX-2*XAXIS_BORDER)*pixelToX+tmp;
      if(logarithmicAxis)
      {
        tmp=minYLog;
        minYLog=Math.pow(10.0,(double)(getHeight()-YAXIS_BORDER-firstPointY)*pixelToYLog)*tmp;
        maxY=Math.pow(10.0,(double)(getHeight()-YAXIS_BORDER-secondPointY)*pixelToYLog)*tmp;
        minY=minYLog;
      }
      else
      {
        tmp=minY;
        minY=(double)(getHeight()-YAXIS_BORDER-firstPointY)*pixelToY+tmp;
        maxY=(double)(getHeight()-YAXIS_BORDER-secondPointY)*pixelToY+tmp;
        if(minY>1e-10) minYLog=minY;
      }

      mouseReleased=false; 
    }
  }

  private void drawLegend(Graphics gg)
  {
    int sizeFont,sizeHalf;
    int symbolSize=8;
    int baselyne;
    FontMetrics metrics = gg.getFontMetrics();

    sizeFont=metrics.getHeight();
    sizeHalf=(int)(sizeFont*0.5);
    baselyne=sizeFont-metrics.getDescent();
    widthLegend=heightLegend=0;

    //Start with a default position of the legend
    if(!isTranslated)
    {
      legendX=2*((int)((double)getWidth()/3.0));
      legendY=YAXIS_BORDER+BORDER;

      oldWidth=getWidth();
      oldHeight=getHeight();
    }

    for(int i=0;i<curves.size();i++)
    {

      gg.setColor(curves.get(i).getColorID());

      //Distinguish between experimental data and simulation
      if(i==0)
      {
        //Paint the leyend of the experimental set only if it is displayed
        if(curves.get(i).isDrawable())
        {
          gg.fillOval(legendX+BORDER,legendY+BORDER+sizeHalf-symbolSize/2,symbolSize,symbolSize);
          gg.drawString("Experiment",legendX+2*BORDER+symbolSize,legendY+BORDER+baselyne);

          heightLegend+=BORDER+sizeFont;
        }
      }
      else
      {
        gg.drawLine(legendX+BORDER-2,legendY+heightLegend+BORDER+sizeHalf,legendX+symbolSize+6,legendY+heightLegend+BORDER+sizeHalf);
        gg.drawLine(legendX+BORDER-2,legendY+heightLegend+BORDER+sizeHalf-1,legendX+symbolSize+6,legendY+heightLegend+BORDER+sizeHalf-1);
        gg.setColor(Color.BLACK);
        gg.drawString("Simulation " + i,legendX+2*BORDER+symbolSize,legendY+heightLegend+BORDER+baselyne);

        heightLegend+=BORDER+sizeFont;
      }
    }

    heightLegend+=BORDER;
    widthLegend=3*BORDER+symbolSize+metrics.stringWidth("Simulation " + curves.size());

    if(curves.size()>0)
    {
      gg.drawRect(legendX,legendY,widthLegend,heightLegend);
    }

    //If we go out of the drawing panel, translate inside the panel and paint again the legend
    if(legendX+widthLegend>getWidth()-XAXIS_BORDER)
    {
      legendX-=legendX+widthLegend-(getWidth()-XAXIS_BORDER);
      this.repaint(); 
    }
    if(legendY+heightLegend>getHeight()-YAXIS_BORDER)
    {
      legendY-=legendY+heightLegend-(getHeight()-YAXIS_BORDER);
      this.repaint();
    }
    if(legendX<2*XAXIS_BORDER)
    {
      legendY=2*XAXIS_BORDER;
      this.repaint();
    }
    if(legendY<YAXIS_BORDER)
    {
      legendY=YAXIS_BORDER;
      this.repaint();
    }

  }

  private void drawTranslatedArea(Graphics gg)
  {
    int firstPointX,firstPointY,secondPointX,secondPointY;

    firstPointX=mousePressedAtX;
    firstPointY=mousePressedAtY;
    secondPointX=mouseDraggedAtX;
    secondPointY=mouseDraggedAtY;

    gg.setColor(Color.BLACK);
    gg.drawRect(legendX+secondPointX-firstPointX,legendY+secondPointY-firstPointY,widthLegend,heightLegend);

  }

  private void calculateTranslatedArea()
  {
    legendX+=mouseReleasedAtX-mousePressedAtX;
    legendY+=mouseReleasedAtY-mousePressedAtY;
    
    mouseReleased=false;
    translatedLegend=false; 
  }

  public void displayLegend(boolean display)
  {
    displayLegend=display;
    this.repaint(); 
  }

  public void drawLogarithmicScale(boolean axisType)
  {
    logarithmicAxis=axisType;
    this.repaint();
  }

  private void registerMousePressed()
  {
    //Listen only to the button 1 events that take place inside the plot area
    if(mousePressedAtX>=2*XAXIS_BORDER && mousePressedAtX<=getWidth()-XAXIS_BORDER &&
       mousePressedAtY>=YAXIS_BORDER   && mousePressedAtY<=getHeight()-YAXIS_BORDER)
    {
      mousePressed=true;
    }
  }

  private void refreshPanel()
  {
    this.repaint();
  }

  public void resetView()
  {
    zoomed=false;
    isTranslated=false;
    this.repaint();
  } 
  
//************************Action listeners***********************************************
//***************************************************************************************
//***************************************************************************************

  private class ZoomTranslateListener implements MouseListener
  {
    public void mouseClicked(MouseEvent event)
    {
    }
    public void mouseEntered(MouseEvent event)
    {
    }
    public void mouseExited(MouseEvent event)
    {
    }
    public void mousePressed(MouseEvent event) 
    {
      if(event.getButton()==event.BUTTON1)
      {
        mousePressedAtX=mouseDraggedAtX=event.getX();
        mousePressedAtY=mouseDraggedAtY=event.getY();

        if(mousePressedAtX>legendX && mousePressedAtX<legendX+widthLegend &&
           mousePressedAtY>legendY && mousePressedAtY<legendY+heightLegend)
        {
          translatedLegend=true;
          isTranslated=true;
        }

        registerMousePressed();

      }
    }
    public void mouseReleased(MouseEvent event)
    {
      mousePressed=false;
      mouseReleased=true;

      mouseReleasedAtX=event.getX();
      mouseReleasedAtY=event.getY();

      if(translatedLegend)
      {
        calculateTranslatedArea();
      }
      else
      {
        calculateZoomArea();
      }

      refreshPanel();
    }
  }

  private class ZTListener implements MouseMotionListener
  {
    public void mouseDragged(MouseEvent event)
    {
      if(mousePressed)
      {
        mouseDraggedAtX=event.getX();
        mouseDraggedAtY=event.getY();

        refreshPanel(); 
      }
    }
    public void mouseMoved(MouseEvent event)
    {
    }
  }

}
