import javax.swing.JFrame;
import javax.swing.WindowConstants;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import java.awt.Desktop;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.net.URI;
import java.net.URISyntaxException;
import java.io.IOException;
import java.lang.reflect.Method; 
import javax.swing.JOptionPane; 
import java.util.Arrays;

public class LumiTrans extends JFrame implements WindowConstants 
{
  private MainPanel mainPanel;
  static final String url="http://homepage.tudelft.nl/v9k6y/LumiTrans/";
  private static final long serialVersionUID = 1L;

  public LumiTrans()
  {
    super ("LumiTrans");
 
    this.setDefaultCloseOperation(this.DO_NOTHING_ON_CLOSE);

    //Create the menu and the main panel for the main frame
    MainMenu mainFrameMenu = new MainMenu();
    mainPanel = new MainPanel(this);
		
    //Add a window listener to close the main frame when requested
    this.addWindowListener(new CloseListener());
				
    //Associate the menu for the main frame with the main frame and add the main panel
    setJMenuBar(mainFrameMenu);

    pack();
    setLocationRelativeTo(null);
    setVisible(true);
    setResizable(false);
  }	


//**************************Class methods************************************************
//***************************************************************************************
//***************************************************************************************

  private void decideClosing()
  {
    if(mainPanel.writeCellInfoFile(false))
    {
      this.dispose();
      System.exit(0);
    }
  }

  private void openWebBrowser()
  {
    try
    {
      Desktop.getDesktop().browse(new URI(url));
    }
    catch(UnsupportedOperationException exception)
    {
      //If the version of the JRE is not 1.6 or above, do open the browser in another way
      openWebBroserOldVersion();
    }
    catch(URISyntaxException exception)
    {
    }
    catch(IOException e)
    {
      JOptionPane.showMessageDialog(this, "Error attempting to launch web browser\n" + e.toString()); 
    }
  }

  private void openWebBroserOldVersion()
  {

    final String[] browsers = { "firefox", "opera", "konqueror", "epiphany", "seamonkey", "galeon", "kazehakase", "mozilla", "netscape" , "links", "lynx" }; 

    String osName = System.getProperty("os.name"); 

    try 
    { 
      if (osName.startsWith("Mac OS")) 
      { 
        Class<?> fileMgr = Class.forName("com.apple.eio.FileManager"); 
        Method openURL = fileMgr.getDeclaredMethod("openURL", new Class[] {String.class}); 
        openURL.invoke(null, new Object[] {url}); 
      } 
      else if (osName.startsWith("Windows")) 
        Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + url); 
      else 
      { 
        //assume Unix or Linux 
        boolean found = false; 

        for (String browser : browsers) 
          if (!found) 
          { 
            found = Runtime.getRuntime().exec( new String[] {"which", browser}).waitFor() == 0; 
            if (found) Runtime.getRuntime().exec(new String[] {browser, url}); 
          } 
          if (!found) throw new Exception(Arrays.toString(browsers));
      } 
    } 
    catch (Exception e) 
    { 
      JOptionPane.showMessageDialog(this, "Error attempting to launch web browser\n" + e.toString()); 
    } 
  }

  private void displayAboutDialog()
  {
    AboutDialog about = new AboutDialog(this);
    about.setVisible(true);
  } 
	
//****************************Menu class*************************************************
//***************************************************************************************
//***************************************************************************************

  private class MainMenu extends JMenuBar
  {
    private static final long serialVersionUID = 1L;

    //Class constructor
    public MainMenu()
    {
      //File menu
      JMenu file = new JMenu ("File");
      file.setMnemonic('F');

      //File menu items
      JMenuItem exit = new JMenuItem("Exit");
      exit.setMnemonic('X');
      exit.addActionListener(new ExitListener());
      file.add(exit);

      //Help menu
      JMenu help = new JMenu ("Help");
      help.setMnemonic('H');

      //Help menu items
      JMenuItem generalHelp = new JMenuItem("General Help");
      generalHelp.setMnemonic('G');
      generalHelp.addActionListener(new GeneralHelpListener());
      help.add(generalHelp);

      help.addSeparator();
      JMenuItem about = new JMenuItem("About");
      about.setMnemonic('A');
      about.addActionListener(new AboutListener());
      help.add(about);

      this.add(file);
      this.add(help);

      this.setVisible(true);
    }
  }

//******************Action listeners of the menu*****************************************
//***************************************************************************************
//***************************************************************************************

  private class ExitListener implements ActionListener
  {
    public void actionPerformed(ActionEvent event)
    {
      decideClosing();
    }
  }


  private class GeneralHelpListener implements ActionListener
  {
    public void actionPerformed(ActionEvent event)
    {
      openWebBrowser();
    }
  }


  private class AboutListener implements ActionListener
  {
    public void actionPerformed(ActionEvent event)
    {
      displayAboutDialog();
    }
  }



//************************Action listeners***********************************************
//***************************************************************************************
//***************************************************************************************

  private class CloseListener extends WindowAdapter
  {
    public void windowClosing(WindowEvent e)
    {
      decideClosing();
    }
  }

//************************Main function**************************************************
//***************************************************************************************
//***************************************************************************************

  public static void main(String[] args)
  {
    LumiTrans mainFrame= new LumiTrans();
  }
}
