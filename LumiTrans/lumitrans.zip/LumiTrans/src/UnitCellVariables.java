//This class will only contain the cell parameters
public class UnitCellVariables 
{
  private double cellParameters[] = new double[3];
  private double angleParameters[] = new double[3];
  private int nParameters[] = new int[3];

  private boolean periodic;

  private int atoms;

  private double positions[][];

  //Empty constructor
  public UnitCellVariables()
  {
  }

//**************************Get methods**************************************************
//***************************************************************************************
//***************************************************************************************

  public double[] getCellParameters()
  {
    return cellParameters;
  }
  public double[] getAngleParameters()
  {
    return angleParameters;
  }
  public int[] getNParameters()
  {
    return nParameters;
  }
  public boolean getPeriodic()
  {
    return periodic;
  }
  public int getAtoms()
  {
    return atoms;
  }
  public double[][] getPositions()
  {
    return positions;
  }


//**************************Set methods**************************************************
//***************************************************************************************
//***************************************************************************************

  public void setCellParameters(double[] xyz)
  {
    cellParameters[0]=xyz[0];
    cellParameters[1]=xyz[1];
    cellParameters[2]=xyz[2];
  }
  public void setAngleParameters(double[] xyz)
  {
    angleParameters[0]=xyz[0];
    angleParameters[1]=xyz[1];
    angleParameters[2]=xyz[2];
  }
  public void setNParameters(int[] xyz)
  {
    nParameters[0]=xyz[0];
    nParameters[1]=xyz[1];
    nParameters[2]=xyz[2];
  }
  public void setPeriodic(boolean per)
  {
    periodic=per;
  }
  public void setAtoms(int a)
  {
    atoms=a;
  }
  //Careful! This function has to be called after setAtoms, if not there will be an exception
  public void setPositions(double[][] p)
  {
    positions = new double[getAtoms()][3];

    for(int i=0;i<getAtoms();i++)
    {
      positions[i][0]=p[i][0];
      positions[i][1]=p[i][1];
      positions[i][2]=p[i][2];
    }
  }
}
