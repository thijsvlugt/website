import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import java.io.File;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import javax.swing.JFileChooser;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class NeighboursFrame extends JDialog
{
  private static final long serialVersionUID = 1L;

  public final int BORDER=7;
  private SimulationVariables cell = new SimulationVariables();
  private CalculatorClass calculator;
  private String neighbourString;
  private JTextArea neighboursTextArea;
  ProgressBar progressBar;
  MainPanel parentPanel;
	
  public NeighboursFrame(MainPanel mainPanel,SimulationVariables cellInfo)
  {
    NeighboursMenu thisFrameMenu = new NeighboursMenu();

    cell=cellInfo;
    parentPanel=mainPanel;
	
    neighboursTextArea = new JTextArea();
    neighboursTextArea.setText(neighbourString);
    neighboursTextArea.setEditable(false);
    neighboursTextArea.setVisible(true);
		
    JScrollPane neighboursScrollPane = new JScrollPane(neighboursTextArea);
    neighboursScrollPane.createVerticalScrollBar();
    neighboursScrollPane.createHorizontalScrollBar();
    neighboursScrollPane.setVisible(true);

    Container thisFrame = getContentPane();
		
    this.setTitle("Neighbour list");
    this.setResizable(false);
    this.setSize(300,400);
    //Add a window listener to close the main frame when requested
    this.setLayout(new BorderLayout());
 
    thisFrame.add(neighboursScrollPane);
    setJMenuBar(thisFrameMenu);

    this.setLocationRelativeTo(mainPanel);		
    thisFrame.setVisible(true);

    //Calculate the neighbour list with a progress bar
    progressBar = new ProgressBar(mainPanel,CalculatorClass.NEIGHBOURS);
    progressBar.setVisible(true);

    //get the neighbour list, display it, and close the progress bar
    neighbourString=progressBar.getNeighbours();
    neighboursTextArea.setText(neighbourString);
    neighboursTextArea.setCaretPosition(0);
    progressBar.closeBar();

    if(mainPanel.isEnoughMemory())
    {
      this.setModalityType(Dialog.ModalityType.TOOLKIT_MODAL);    
    }
    else
    {
      this.setModalityType(Dialog.ModalityType.MODELESS);
    }
  }	


//****************************Menu class*************************************************
//***************************************************************************************
//***************************************************************************************

  private class NeighboursMenu extends JMenuBar
  {
    private static final long serialVersionUID = 1L;

    //Class constructor
    public NeighboursMenu()
    {
      JMenu file = new JMenu ("File");
      file.setMnemonic('F');

      JMenuItem save = new JMenuItem("Save");
      save.setMnemonic('S');
      save.addActionListener(new SaveNeighboursListener());
      file.add(save);

      file.addSeparator();

      JMenuItem exit = new JMenuItem("Exit");
      exit.setMnemonic('X');
      exit.addActionListener(new CloseListener());
      file.add(exit);

      this.add(file);
      this.setVisible(true);
    }
  }


//**************************Class methods************************************************
//***************************************************************************************
//***************************************************************************************


  private void saveNeighboursFile()
  {
    int saveFileResult;
    File neighboursFile=null;

    //Open a file chooser for files only, and store the action of the user
    JFileChooser myFileChooser = new JFileChooser("./NeighbourList");
    myFileChooser.setFileSelectionMode(myFileChooser.FILES_ONLY);

    saveFileResult=myFileChooser.showSaveDialog(this);

    //We exit this method if the user press cancel
    if (saveFileResult==JFileChooser.CANCEL_OPTION)
    {
      return;
    }

    //store the file chosen by the user
    neighboursFile=myFileChooser.getSelectedFile();

    //Check that the file name is valid
    if((neighboursFile==null)||(neighboursFile.getName().equals("")))
    {
      JOptionPane.showMessageDialog(this,"File name not valid",
                                      "File not valid", JOptionPane.ERROR_MESSAGE);
    }
    else
    {
      try
      {
        //Create an output buffer for the file
        FileOutputStream neighboursStream = new FileOutputStream(neighboursFile);
        PrintWriter neighboursWriter = new PrintWriter(neighboursStream);

        //We write in the output the information in the right format
        neighboursWriter.print(neighbourString);

        neighboursWriter.close();
        neighboursStream.close();
        neighboursFile=null;
      }
      catch (IOException excepcion)
      {
        JOptionPane.showMessageDialog(this,"The selected file could not be saved",
                                     "Save file error", JOptionPane.ERROR_MESSAGE);
        return;
      }

    }
  }

//**************************Helper methods***********************************************
//***************************************************************************************
//***************************************************************************************

  private void closeFrame()
  {
    this.dispose(); 
  }


//************************Action listeners***********************************************
//***************************************************************************************
//***************************************************************************************

  private class SaveNeighboursListener implements ActionListener
  {
    public void actionPerformed(ActionEvent event)
    {
      saveNeighboursFile(); 
    }
  }

  private class CloseListener implements ActionListener
  {
    public void actionPerformed(ActionEvent event)
    {			
      closeFrame();
    }
  }
	
}
